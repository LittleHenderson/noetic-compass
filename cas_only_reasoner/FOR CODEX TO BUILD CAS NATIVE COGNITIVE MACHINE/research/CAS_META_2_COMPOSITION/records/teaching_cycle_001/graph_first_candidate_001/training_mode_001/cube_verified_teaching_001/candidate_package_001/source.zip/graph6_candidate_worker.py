"""Rendered candidate worker: the checked-component pilot, one run."""
import hashlib
import json
import os
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / 'config.json').read_text())
ARTIFACTS = ROOT / 'artifacts'
ARTIFACTS.mkdir(exist_ok=True)


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def upload(s3, bucket, key, path):
    s3.upload_file(str(path), bucket, key)
    return {'key': key, 'bytes': path.stat().st_size,
            'sha256': sha256_file(path)}


def state_digest(module):
    digest = hashlib.sha256()
    for name, tensor in module.state_dict().items():
        # registration order, exactly as GraphLearner.checkpoint_identity
        # hashes it, so the round trip compares like with like
        digest.update(name.encode('utf-8'))
        digest.update(tensor.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


def main():
    from cas_meta2.graph_teaching import candidate_experiment as ce
    from cas_meta2.graph_teaching import trainer
    from cas_meta2.teaching_cycle import gpu_adapter
    from cas_meta2.graph_teaching.real_framework import (
        build_encoder, build_graph_training_framework, GraphLearner)
    from cas_meta2.graph_teaching import adapter
    torch, device = gpu_adapter._cuda()
    inputs = ce.build_inputs(ordering_mode=CONFIG['ordering_mode'])
    records, probe = inputs['records'], inputs['probe']
    publics = [adapter.public_records(record, CONFIG['arm'])['public']
               for record in records + probe]
    encoder = build_encoder(torch, publics, d_model=64,
                            seed=CONFIG['encoder_seed'], device=device)
    condition_order = list(CONFIG['conditions'])

    def framework_factory(seed):
        torch.manual_seed(seed)
        framework = build_graph_training_framework(
            torch, device, seed=CONFIG['encoder_seed'], encoder=encoder)
        model = framework.build_decompose_model(seed=seed)
        return framework, model

    def learner_factory(*, framework, model, arm, records, layout):
        tasks = [layout[record['record_id']] for record in records]
        learner = GraphLearner(torch, framework, tasks, device,
                               CONFIG['learning_rate'])
        # conditions run in the frozen order, so the tag follows that order
        learner.condition_tag = condition_order.pop(0)
        return learner

    def checkpoint_writer(learner, identity):
        path = ARTIFACTS / ('checkpoint_%s.pt' % learner.condition_tag)
        torch.save({'schema': 'cas-graph-training-candidate-checkpoint/1',
                    'condition': learner.condition_tag,
                    'identity': identity,
                    'state': learner.module.state_dict()}, str(path))
        return {'path': str(path), 'identity': identity,
                'sha256': sha256_file(path)}

    def checkpoint_verifier(saved, identity):
        loaded = torch.load(saved['path'], map_location='cpu',
                            weights_only=True)
        digest = hashlib.sha256()
        for name, tensor in loaded['state'].items():
            digest.update(name.encode('utf-8'))
            digest.update(tensor.detach().cpu().numpy().tobytes())
        return digest.hexdigest() == identity and loaded['identity'] == identity

    authorization = {'owner_go': True, 'run_id': CONFIG['job'],
                     'authority_sha256': CONFIG['authority_sha256']}
    result = ce.launch(run_id=CONFIG['job'], records=records, probe=probe,
                       groups=inputs['groups'],
                       framework_factory=framework_factory,
                       learner_factory=learner_factory,
                       authorization=authorization,
                       checkpoint_writer=checkpoint_writer,
                       checkpoint_verifier=checkpoint_verifier,
                       view_id=CONFIG['view_id'],
                       ordering_mode=CONFIG['ordering_mode'])
    (ARTIFACTS / 'result.json').write_text(
        json.dumps(result, sort_keys=True, indent=2, allow_nan=False))
    return result


def upload_results(s3, bucket, results):
    uploaded = []
    for path in sorted(ARTIFACTS.iterdir()):
        if path.name == 'result.json':
            continue
        uploaded.append(upload(s3, bucket, 'results/' + path.name, path))
    manifest = {'schema': 'cas-graph-training-candidate-delivery/1',
                'job': CONFIG['job'], 'artifacts': uploaded}
    (ARTIFACTS / 'manifest.json').write_text(
        json.dumps(manifest, sort_keys=True, indent=2, allow_nan=False))
    uploaded.append(upload(s3, bucket, 'results/manifest.json',
                           ARTIFACTS / 'manifest.json'))
    # result.json goes LAST: collection treats it as the completion marker
    uploaded.append(upload(s3, bucket, 'results/result.json',
                           ARTIFACTS / 'result.json'))
    return manifest


def main_guarded():
    import boto3
    s3 = boto3.client('s3', region_name=CONFIG['region'])
    bucket = CONFIG['bucket']
    try:
        main()
        manifest = upload_results(s3, bucket, None)
        print(json.dumps({'worker_status': 'REMOTE_FINISHED',
                          'artifacts': len(manifest['artifacts'])}))
    except BaseException:
        failure = {'schema': 'cas-graph-training-candidate-failure/1',
                   'job': CONFIG['job'],
                   'traceback': traceback.format_exc()[:20000]}
        (ARTIFACTS / 'failure.json').write_text(
            json.dumps(failure, sort_keys=True))
        partial = {'schema': 'cas-graph-training-candidate-result/1',
                   'job': CONFIG['job'], 'status': 'WORKER_FAILED',
                   'failure': failure}
        (ARTIFACTS / 'result_partial.json').write_text(
            json.dumps(partial, sort_keys=True))
        try:
            upload_results(s3, bucket, None)
        except BaseException:
            pass
        print('WORKER_FAILED')
        raise SystemExit(1)


if __name__ == '__main__':
    main_guarded()
