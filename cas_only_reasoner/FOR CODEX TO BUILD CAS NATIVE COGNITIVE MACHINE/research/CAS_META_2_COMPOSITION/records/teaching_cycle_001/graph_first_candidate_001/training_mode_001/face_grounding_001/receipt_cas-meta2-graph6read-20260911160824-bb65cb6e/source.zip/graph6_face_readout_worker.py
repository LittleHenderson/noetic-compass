"""GRAPH6 face-readout worker: read the delivered checkpoints, train nothing.

The body lives in the packaged module cas_meta2.graph_teaching.face_readout,
so the rehearsal executes it in-process. This script only prepares the
environment, runs the body under that environment's python, and uploads what
it wrote - result.json last, because that is the completion marker."""
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

RESULT_SCHEMA = 'cas.cube-face-readout-result/1'
FAILURE_SCHEMA = 'cas.cube-face-readout-failure/1'
ARTIFACT_MANIFEST_KEY = 'results/artifacts/manifest.json'
MAX_WALL_SECONDS = 1200.0
TORCH_INDEX = 'https://download.pytorch.org/whl/cu128'
PILOT = 'research/CAS_META_2_COMPOSITION'
WHEEL_DIR = 'research/CAS_CJT_TRANSFORMER_v0_2/artifacts/release_reproduction/dist'
WHEEL_NAMES = (
    'casformer_reference-0.1.0-py3-none-any.whl',
    'cas_neural_cjt-0.2.0-py3-none-any.whl',
)
REQUIREMENTS = 'research/CAS_META_2_COMPOSITION/requirements-gpu.txt'

INNER_RUNNER = "\n".join((
    'import json',
'import sys',
'from pathlib import Path',
'ROOT = Path(sys.argv[1])',
"sys.path.insert(0, str(ROOT / 'research/CAS_META_2_COMPOSITION'))",
'from cas_meta2.graph_teaching import face_readout',
'from cas_meta2.teaching_cycle import gpu_adapter',
"CONFIG = json.loads((ROOT / 'config.json').read_bytes())",
'torch, device = gpu_adapter._cuda()',
"RESULTS = ROOT / 'results'",
"ARTIFACTS = RESULTS / 'artifacts'",
'ARTIFACTS.mkdir(parents=True, exist_ok=True)',
'report = face_readout.run(CONFIG, torch=torch, device=device,',
'                          results=RESULTS, artifacts=ARTIFACTS,',
'                          root=ROOT, outbound=None)',
"print(json.dumps({'inner_status': 'READOUT_WRITTEN',",
"                  'status': report['envelope']['status'],",
"                  'reproduced': report['envelope']['reproduction']",
"                                ['reproduced'],",
"                  'artifacts': len(report['envelope']['artifacts'])}))"
))


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def run_checked(argv):
    subprocess.run(argv, check=True)


def read_json(path, default=None):
    if not path.is_file():
        return default
    return json.loads(path.read_bytes())


def main():
    root = Path(__file__).resolve().parent
    config = json.loads((root / 'config.json').read_bytes())
    job = config['job']
    bucket = config['bucket']
    region = config['region']
    results = root / 'results'
    results.mkdir(exist_ok=True)
    failure = None
    try:
        venv = root / 'venv'
        venv_py = venv / 'bin' / 'python'
        if not venv_py.exists():
            base = next((c for c in ('python3.12', 'python3.11', 'python3')
                         if shutil.which(c)), None)
            if base is None:
                raise SystemExit('SUPPORTED_PYTHON_REQUIRED')
            run_checked([base, '-m', 'venv', str(venv)])
        python = str(venv_py)
        run_checked([python, '-m', 'pip', 'install',
                     '--disable-pip-version-check', 'torch==2.11.0',
                     '--index-url', TORCH_INDEX])
        wheels = [str(root / WHEEL_DIR / name) for name in WHEEL_NAMES]
        run_checked([python, '-m', 'pip', 'install',
                     '--disable-pip-version-check', '--no-deps', *wheels])
        run_checked([python, '-m', 'pip', 'install',
                     '--disable-pip-version-check', '-r',
                     str(root / REQUIREMENTS)])
        runner = root / '_inner_runner.py'
        runner.write_text(INNER_RUNNER)
        inner = subprocess.run([python, '-B', str(runner), str(root)],
                               capture_output=True, text=True,
                               timeout=MAX_WALL_SECONDS + 1800)
        if inner.returncode != 0:
            detail = (inner.stderr or inner.stdout or '')[-1800:]
            failure = {'type': 'InnerRunnerFailure',
                       'message': 'INNER_RUNNER_EXIT_' + str(inner.returncode)
                                  + '\n' + detail}
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)[:2000]}
    results_dir = results
    if failure is None:
        try:
            raw = (results_dir / 'result.json').read_bytes()
            sidecar = (results_dir / 'result.json.sha256').read_text().strip()
            if hashlib.sha256(raw).hexdigest() != sidecar:
                failure = {'type': 'ResultMismatch',
                           'message': 'RESULT_SHA_MISMATCH'}
        except BaseException as error:
            failure = {'type': 'DeliveryIncomplete',
                       'message': 'RESULT_MARKER_MISSING:' + str(error)[:200]}
    if failure is not None:
        if (results_dir / 'result.json').is_file():
            preserved = (results_dir / 'result.json').read_bytes()
            (results_dir / 'result_partial.json').write_bytes(preserved)
        report = {'schema': RESULT_SCHEMA, 'job': job,
                  'status': 'WORKER_FAILED', 'failure': failure,
                  'artifacts': [], 'measurements': None}
        raw = (json.dumps(report, sort_keys=True, indent=2,
                          allow_nan=False) + '\n').encode('utf-8')
        (results_dir / 'result.json').write_bytes(raw)
        (results_dir / 'result.json.sha256').write_text(
            hashlib.sha256(raw).hexdigest() + '\n')
        (results_dir / 'failure.json').write_text(
            json.dumps({'schema': FAILURE_SCHEMA, 'job': job,
                        'failure': failure}, sort_keys=True, indent=2) + '\n')
    import boto3
    s3 = boto3.client('s3', region_name=region)
    uploaded = upload_results(s3, bucket, results_dir.parent)
    print(json.dumps({'worker_status': ('REMOTE_FAILED' if failure is not None
                                         else 'REMOTE_FINISHED'),
                      'artifacts': len(uploaded['artifacts']),
                      'result_uploaded': uploaded['result']}))
    if failure is not None:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
def evidence_files(root):
    """Every regular file under the evidence directory, no suffix filter."""
    base = root / 'results'
    found = []
    for path in sorted(base.rglob('*')):
        if path.is_file() and not path.is_symlink():
            found.append(path)
    return found


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def publish_once(s3, bucket, root, published, marker_name='result.json',
                 sidecar_name='result.json.sha256'):
    """Upload new completed files. Create-only where the SDK supports it."""
    uploaded, skipped = [], []
    for path in evidence_files(root):
        key = path.relative_to(root).as_posix()
        if key.endswith('.partial') or key.endswith('.tmp'):
            skipped.append(key)
            continue
        if key.endswith(marker_name) or key.endswith(sidecar_name):
            skipped.append(key)          # the transport marker goes last
            continue
        digest_value = sha256_file(path)
        if published.get(key) == digest_value:
            continue
        body = path.read_bytes()
        try:
            s3.put_object(Bucket=bucket, Key=key, Body=body,
                          IfNoneMatch='*')
        except Exception as error:                      # noqa: BLE001
            code = getattr(error, 'response', {}).get('Error', {}).get('Code')
            if code in ('PreconditionFailed', 'ConditionalRequestConflict'):
                existing = s3.get_object(Bucket=bucket, Key=key)
                current = existing['Body'].read()
                if hashlib.sha256(current).hexdigest() != digest_value:
                    raise SystemExit('EVIDENCE_DIGEST_CONFLICT:' + key)
                published[key] = digest_value
                continue
            raise
        published[key] = digest_value
        uploaded.append({'key': key, 'sha256': digest_value,
                         'bytes': len(body)})
    return {'uploaded': uploaded, 'skipped': skipped,
            'published_sequence': len(published),
            'transport_tail': [key for key in skipped
                               if key.endswith(marker_name)
                               or key.endswith(sidecar_name)],
            'unuploaded_tail': [key for key in
                                (path.relative_to(root).as_posix()
                                 for path in evidence_files(root))
                                if key not in published
                                and not key.endswith(marker_name)
                                and not key.endswith(sidecar_name)]}


def upload_results(s3, bucket, root, published=None):
    """The inventory, then the sidecar, then the transport marker LAST."""
    published = {} if published is None else published
    results = root / 'results'
    upload = publish_once(s3, bucket, root, published, 'result.json', 'result.json.sha256')
    manifest = results / 'artifacts' / 'manifest.json'
    if manifest.is_file():
        s3.put_object(Bucket=bucket, Key='results/artifacts/manifest.json',
                      Body=manifest.read_bytes())
    sidecar_path = results / 'result.json.sha256'
    if sidecar_path.is_file():
        s3.put_object(Bucket=bucket,
                      Key='results/' + 'result.json.sha256',
                      Body=sidecar_path.read_bytes())
    marker_path = results / 'result.json'
    if marker_path.is_file():
        s3.put_object(Bucket=bucket,
                      Key='results/' + 'result.json',
                      Body=marker_path.read_bytes())
        upload['marker'] = True
    upload['marker_meaning'] = ('the producer finished publishing its current inventory; it grants neither collection completeness nor evidence deletion')
    return upload


def publisher(s3, bucket, root, published, stop, errors, seconds):
    """Publish completed files while the body runs; bounded unsaved work."""
    import time
    while not stop.is_set():
        try:
            publish_once(s3, bucket, root, published, 'result.json', 'result.json.sha256')
        except BaseException as error:                # noqa: BLE001
            errors.append(type(error).__name__ + ':' + str(error)[:500])
        stop.wait(seconds)

