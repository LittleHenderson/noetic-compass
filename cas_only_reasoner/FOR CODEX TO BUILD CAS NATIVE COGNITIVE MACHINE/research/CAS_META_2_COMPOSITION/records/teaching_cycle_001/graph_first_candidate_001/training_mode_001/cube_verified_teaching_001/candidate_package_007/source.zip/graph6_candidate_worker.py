"""Rendered candidate worker: the checked-component pilot, one run.

Environment and delivery follow the proven curriculum worker, step for
step. Attempt 005 died here because the training body ran under the system
python, which has no torch."""
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

RESULT_SCHEMA = 'cas-graph-training-candidate-result/1'
FAILURE_SCHEMA = 'cas-graph-training-candidate-failure/1'
DELIVERY_SCHEMA = 'cas-graph-training-candidate-delivery/1'
ARTIFACT_MANIFEST_KEY = 'results/artifacts/manifest.json'
MAX_WALL_SECONDS = 600.0
CONDITIONS = 2
TORCH_INDEX = 'https://download.pytorch.org/whl/cu128'
PILOT = 'research/CAS_META_2_COMPOSITION'
WHEEL_DIR = 'research/CAS_CJT_TRANSFORMER_v0_2/artifacts/release_reproduction/dist'
WHEEL_NAMES = (
    'casformer_reference-0.1.0-py3-none-any.whl',
    'cas_neural_cjt-0.2.0-py3-none-any.whl',
)
REQUIREMENTS = 'research/CAS_META_2_COMPOSITION/requirements-gpu.txt'

INNER_RUNNER = "\n".join((
    'import hashlib',
'import json',
'import sys',
'from pathlib import Path',
'ROOT = Path(sys.argv[1])',
"sys.path.insert(0, str(ROOT / 'research/CAS_META_2_COMPOSITION'))",
'from cas_meta2.graph_teaching import candidate_experiment as ce',
'from cas_meta2.teaching_cycle import gpu_adapter',
'from cas_meta2.graph_teaching.real_framework import (',
'    build_encoder, build_graph_training_framework, GraphLearner)',
'from cas_meta2.graph_teaching import adapter',
"CONFIG = json.loads((ROOT / 'config.json').read_bytes())",
"RESULTS = ROOT / 'results'",
"ARTIFACTS = RESULTS / 'artifacts'",
'ARTIFACTS.mkdir(parents=True, exist_ok=True)',
'',
'',
'# The outer worker has its own copy; this one runs under the venv python.',
'def sha256_file(path):',
'    digest = hashlib.sha256()',
"    with open(path, 'rb') as stream:",
"        for block in iter(lambda: stream.read(1 << 20), b''):",
'            digest.update(block)',
'    return digest.hexdigest()',
'',
'',
'torch, device = gpu_adapter._cuda()',
"inputs = ce.build_inputs(ordering_mode=CONFIG['ordering_mode'])",
"records, probe = inputs['records'], inputs['probe']",
"publics = [adapter.public_records(record, CONFIG['arm'])['public']",
'           for record in records + probe]',
'encoder = build_encoder(torch, publics, d_model=64,',
"                        seed=CONFIG['encoder_seed'], device=device)",
"condition_order = list(CONFIG['conditions'])",
'staged = []',
'',
'def framework_factory(seed):',
'    torch.manual_seed(seed)',
'    framework = build_graph_training_framework(',
"        torch, device, seed=CONFIG['encoder_seed'], encoder=encoder)",
'    model = framework.build_decompose_model(seed=seed)',
'    return framework, model',
'',
'def learner_factory(*, framework, model, arm, records, layout):',
"    tasks = [layout[record['record_id']] for record in records]",
'    learner = GraphLearner(torch, framework, tasks, device,',
"                           CONFIG['learning_rate'])",
'    # conditions run in the frozen order, so the tag follows that order',
'    learner.condition_tag = condition_order.pop(0)',
'    return learner',
'',
'def checkpoint_writer(learner, identity):',
"    path = ARTIFACTS / ('checkpoint_%s.pt' % learner.condition_tag)",
"    torch.save({'schema': 'cas-graph-training-candidate-checkpoint/1',",
"                'condition': learner.condition_tag,",
"                'identity': identity,",
"                # the order the learner's own identity digests them in",
"                'parameter_order': ce.parameter_order(learner.module),",
"                'state': learner.module.state_dict()}, str(path))",
"    staged.append({'name': path.name,",
"                   'condition': learner.condition_tag,",
"                   'identity': identity, 'bytes': path.stat().st_size,",
"                   'sha256': sha256_file(path)})",
"    return {'path': str(path), 'identity': identity,",
"            'sha256': sha256_file(path)}",
'',
'def checkpoint_verifier(saved, identity):',
"    loaded = torch.load(saved['path'], map_location='cpu',",
'                        weights_only=True)',
"    # Read back from disk and recompute with the learner's own rule. Hashing",
'    # the parameter names too could never equal the identity, and the run',
'    # would then fail closed after its whole budget was already spent.',
"    recomputed = ce.state_digest(loaded['state'], loaded['parameter_order'])",
"    return (recomputed == identity and loaded['identity'] == identity)",
'',
"authorization = {'owner_go': True, 'run_id': CONFIG['job'],",
"                 'authority_sha256': CONFIG['authority_sha256']}",
"result = ce.launch(run_id=CONFIG['job'], records=records, probe=probe,",
"                   groups=inputs['groups'],",
'                   framework_factory=framework_factory,',
'                   learner_factory=learner_factory,',
'                   authorization=authorization,',
'                   checkpoint_writer=checkpoint_writer,',
'                   checkpoint_verifier=checkpoint_verifier,',
"                   view_id=CONFIG['view_id'],",
"                   ordering_mode=CONFIG['ordering_mode'])",
'def write_json(path, payload):',
'    path.write_text(json.dumps(payload, sort_keys=True, indent=2,',
"                               allow_nan=False) + '\\n')",
'',
"write_json(RESULTS / 'measurements.json', result)",
"write_json(ARTIFACTS / 'manifest.json',",
"           {'schema': 'cas-graph-training-candidate-artifact-manifest/1',",
"            'job': CONFIG['job'], 'artifacts': staged})",
"print(json.dumps({'inner_status': 'MEASUREMENTS_WRITTEN',",
"                  'conditions': list(result['results']),",
"                  'artifacts': len(staged)}))"
))


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def run_checked(argv):
    subprocess.run(argv, check=True)


def read_json(path, default=None):
    if not path.is_file():
        return default
    return json.loads(path.read_bytes())


def build_envelope(job, failure, measurements, artifacts):
    if failure is not None:
        return {'schema': RESULT_SCHEMA, 'job': job,
                'status': 'WORKER_FAILED', 'artifacts': [],
                'failure': failure,
                'measurements': None}
    return {'schema': RESULT_SCHEMA, 'job': job,
            'status': 'REMOTE_FINISHED', 'failure': None,
            # Declared, so verified collection collects them instead of
            # deleting a bucket whose checkpoints were never delivered.
            'artifacts': [{'name': entry['name'],
                           'condition': entry.get('condition'),
                           'identity': entry.get('identity'),
                           'bytes': entry.get('bytes'),
                           'sha256': entry.get('sha256')}
                          for entry in artifacts],
            'measurements': measurements}


def upload_results(s3, bucket, results):
    """Artifacts and manifest, then the sidecar, then the result LAST.

    Runs in the OUTER process (system python, which has the AWS SDK), so the
    training venv never needs boto3. result.json is the marker the launcher
    waits for, so its presence means every artifact is already there."""
    uploaded = {'artifacts': [], 'manifest': False, 'result': False,
                'result_sha256': False}
    artifacts = results / 'artifacts'
    manifest = read_json(artifacts / 'manifest.json')
    if manifest:
        s3.put_object(Bucket=bucket, Key=ARTIFACT_MANIFEST_KEY,
                      Body=(artifacts / 'manifest.json').read_bytes())
        uploaded['manifest'] = True
        for entry in manifest['artifacts']:
            path = artifacts / entry['name']
            if path.is_file():
                s3.put_object(Bucket=bucket,
                              Key='results/artifacts/' + entry['name'],
                              Body=path.read_bytes())
                uploaded['artifacts'].append(entry['name'])
    for name in ('measurements.json', 'failure.json', 'result_partial.json',
                 'result.json.sha256'):
        path = results / name
        if path.is_file():
            s3.put_object(Bucket=bucket, Key='results/' + name,
                          Body=path.read_bytes())
            uploaded[name] = True
    path = results / 'result.json'
    if path.is_file():
        s3.put_object(Bucket=bucket, Key='results/result.json',
                      Body=path.read_bytes())
        uploaded['result'] = True
    return uploaded


def main():
    root = Path(__file__).resolve().parent
    config = json.loads((root / 'config.json').read_bytes())
    job = config['job']
    bucket = config['bucket']
    region = config['region']
    results = root / 'results'
    results.mkdir(exist_ok=True)
    failure = None
    try:
        venv = root / 'venv'
        venv_py = venv / 'bin' / 'python'
        if not venv_py.exists():
            base = next((c for c in ('python3.12', 'python3.11', 'python3')
                         if shutil.which(c)), None)
            if base is None:
                raise SystemExit('SUPPORTED_PYTHON_REQUIRED')
            run_checked([base, '-m', 'venv', str(venv)])
        python = str(venv_py)
        run_checked([python, '-m', 'pip', 'install',
                     '--disable-pip-version-check', 'torch==2.11.0',
                     '--index-url', TORCH_INDEX])
        wheels = [str(root / WHEEL_DIR / name) for name in WHEEL_NAMES]
        run_checked([python, '-m', 'pip', 'install',
                     '--disable-pip-version-check', '--no-deps', *wheels])
        run_checked([python, '-m', 'pip', 'install',
                     '--disable-pip-version-check', '-r',
                     str(root / REQUIREMENTS)])
        runner = root / '_inner_runner.py'
        runner.write_text(INNER_RUNNER)
        inner = subprocess.run([python, '-B', str(runner), str(root)],
                               capture_output=True, text=True,
                               timeout=MAX_WALL_SECONDS * CONDITIONS + 2400)
        if inner.returncode != 0:
            detail = (inner.stderr or inner.stdout or '')[-1800:]
            failure = {'type': 'InnerRunnerFailure',
                       'message': 'INNER_RUNNER_EXIT_' + str(inner.returncode)
                                  + '\n' + detail}
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)[:2000]}
    artifacts_dir = results / 'artifacts'
    manifest = read_json(artifacts_dir / 'manifest.json', {}) or {}
    measurements = read_json(results / 'measurements.json')
    staged = manifest.get('artifacts') or []
    if failure is None and measurements is None:
        failure = {'type': 'DeliveryIncomplete',
                   'message': 'MEASUREMENTS_MISSING_AFTER_INNER_RUN'}
    envelope = build_envelope(job, failure, measurements, staged)
    raw = (json.dumps(envelope, sort_keys=True, indent=2,
                      allow_nan=False) + '\n').encode('utf-8')
    (results / 'result.json').write_bytes(raw)
    (results / 'result.json.sha256').write_text(
        hashlib.sha256(raw).hexdigest() + '\n')
    if failure is not None:
        # NEVER destroy a result the run already produced: keep it, and record
        # the failure beside it. The result marker is written even on failure,
        # because the launcher's wait loop only watches result.json: a failure
        # that reported itself nowhere left attempt 004 idling until timeout.
        (results / 'failure.json').write_text(
            json.dumps({'schema': FAILURE_SCHEMA, 'job': job,
                        'failure': failure}, sort_keys=True, indent=2) + '\n')
        if measurements is not None:
            (results / 'result_partial.json').write_text(
                json.dumps(measurements, sort_keys=True, indent=2,
                           allow_nan=False) + '\n')
    import boto3
    s3 = boto3.client('s3', region_name=region)
    uploaded = upload_results(s3, bucket, results)
    print(json.dumps({'worker_status': ('REMOTE_FAILED' if failure is not None
                                         else 'REMOTE_FINISHED'),
                      'artifacts': len(uploaded['artifacts']),
                      'result_uploaded': uploaded['result']}))
    if failure is not None:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
