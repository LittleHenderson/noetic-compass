#!/usr/bin/env python3
"""GRAPH6_CURRICULUM_002 worker. One run, no restart: six learners
(three paired seeds x two curricula), checkpoints at 64 and 256 updates,
one untouched final panel, real checkpoint files uploaded for
collection. Original inner errors are preserved."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

MAX_WALL_SECONDS = 900.0
LEARNERS = 6
TORCH_INDEX = 'https://download.pytorch.org/whl/cu128'
PILOT = 'research/CAS_META_2_COMPOSITION'
WHEEL_DIR = 'research/CAS_CJT_TRANSFORMER_v0_2/artifacts/release_reproduction/dist'
WHEEL_NAMES = (
    'casformer_reference-0.1.0-py3-none-any.whl',
    'cas_neural_cjt-0.2.0-py3-none-any.whl',
)
REQUIREMENTS = 'research/CAS_META_2_COMPOSITION/requirements-gpu.txt'

INNER_RUNNER = "\n".join((
    'import hashlib',
'import json',
'import sys',
'from pathlib import Path',
'ROOT = Path(sys.argv[1])',
"sys.path.insert(0, str(ROOT / 'research/CAS_META_2_COMPOSITION'))",
'from cas_meta2.graph_teaching import (adapter, curriculum, final_panel,',
'                                      trainer, curriculum_experiment)',
'from cas_meta2.graph_teaching.real_framework import build_encoder',
'from cas_meta2.teaching_cycle import gpu_adapter',
"config = json.loads((ROOT / 'config.json').read_bytes())",
"job = config['job']",
'torch, device = gpu_adapter._cuda()',
'# Frozen candidate: the SAME teaching records and encoder as before. The',
'# final panel and the varied curriculum never enter tokenizer fitting.',
'records = trainer.training_records(20260909)',
"publics = [adapter.public_records(r, 'cas')['public'] for r in records]",
'encoder = build_encoder(torch, publics, d_model=64, seed=20260909,',
'                       device=device)',
"tasks = [adapter.public_records(record, 'cas') for record in records]",
'panel = final_panel.build_final_panel()',
"checkpoint_dir = ROOT / 'results' / 'checkpoints'",
'report = curriculum_experiment.launch(',
'    run_id=job, torch=torch, device=device, encoder=encoder,',
'    tasks=tasks, panel=panel, checkpoint_dir=checkpoint_dir)',
"report['job'] = job",
"raw = (json.dumps(report, sort_keys=True, indent=2) + '\\n').encode('utf-8')",
"results = ROOT / 'results'",
'results.mkdir(exist_ok=True)',
"(results / 'result.json').write_bytes(raw)",
"(results / 'result.json.sha256').write_text(hashlib.sha256(raw).hexdigest() + '\\n')",
'# Upload the real checkpoint files and an artifact manifest.',
'import boto3',
"s3 = boto3.client('s3', region_name=config['region'])",
"bucket = config['bucket']",
'manifest = []',
"for artifact in report['artifacts']:",
"    path = Path(artifact['path'])",
'    name = path.name',
'    body = path.read_bytes()',
"    s3.put_object(Bucket=bucket, Key='results/artifacts/' + name, Body=body)",
"    manifest.append({'name': name, 'bytes': len(body),",
"                     'sha256': hashlib.sha256(body).hexdigest(),",
"                     'step': artifact['step'],",
"                     'condition': artifact['condition'],",
"                     'learner_seed': artifact['learner_seed']})",
"s3.put_object(Bucket=bucket, Key='results/artifacts/manifest.json',",
"              Body=(json.dumps({'artifacts': manifest}, sort_keys=True,",
"                               indent=2) + '\\n').encode('utf-8'))"
))

def run_checked(argv):
    subprocess.run(argv, check=True)

def main():
    root = Path(__file__).resolve().parent
    config = json.loads((root / 'config.json').read_bytes())
    job = config['job']
    bucket = config['bucket']
    region = config['region']
    results = root / 'results'
    results.mkdir(exist_ok=True)
    try:
        venv = root / 'venv'
        venv_py = venv / 'bin' / 'python'
        if not venv_py.exists():
            base = next((c for c in ('python3.12', 'python3.11', 'python3')
                         if shutil.which(c)), None)
            if base is None:
                raise SystemExit('SUPPORTED_PYTHON_REQUIRED')
            run_checked([base, '-m', 'venv', str(venv)])
        python = str(venv_py)
        run_checked([python, '-m', 'pip', 'install', '--disable-pip-version-check',
                     'torch==2.11.0', '--index-url', TORCH_INDEX])
        wheels = [str(root / WHEEL_DIR / name) for name in WHEEL_NAMES]
        run_checked([python, '-m', 'pip', 'install', '--disable-pip-version-check',
                     '--no-deps', *wheels])
        run_checked([python, '-m', 'pip', 'install', '--disable-pip-version-check',
                     '-r', str(root / REQUIREMENTS)])
        runner = root / '_inner_runner.py'
        runner.write_text(INNER_RUNNER)
        inner = subprocess.run([python, '-B', str(runner), str(root)],
                             capture_output=True, text=True,
                             timeout=MAX_WALL_SECONDS * LEARNERS + 2400)
        if inner.returncode != 0:
            detail = (inner.stderr or inner.stdout or '')[-1800:]
            raise SystemExit('INNER_RUNNER_EXIT_' + str(inner.returncode) + '\n' + detail)
        raw = (results / 'result.json').read_bytes()
        sidecar = (results / 'result.json.sha256').read_text().strip()
        if hashlib.sha256(raw).hexdigest() != sidecar:
            raise SystemExit('RESULT_SHA_MISMATCH')
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)[:2000]}
        report = {'schema': 'cas-graph-training-curriculum-result/1',
                  'status': 'REMOTE_WORKER_FAILED', 'failure': failure, 'job': job}
        raw = (json.dumps(report, sort_keys=True, indent=2) + '\n').encode('utf-8')
        (results / 'result.json').write_bytes(raw)
        (results / 'result.json.sha256').write_text(hashlib.sha256(raw).hexdigest() + '\n')
    import boto3
    s3 = boto3.client('s3', region_name=region)
    s3.put_object(Bucket=bucket, Key='results/result.json',
                  Body=(results / 'result.json').read_bytes())
    s3.put_object(Bucket=bucket, Key='results/result.json.sha256',
                  Body=(results / 'result.json.sha256').read_bytes())

if __name__ == '__main__':
    main()
