#!/usr/bin/env python3
"""GRAPH6_CURRICULUM_002 worker. One run, no restart: six learners
(three paired seeds x two curricula), checkpoints at 64 and 256 updates,
one untouched final panel, real checkpoint files uploaded for
collection. Original inner errors are preserved."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

MAX_WALL_SECONDS = 900.0
LEARNERS = 6
TORCH_INDEX = 'https://download.pytorch.org/whl/cu128'
PILOT = 'research/CAS_META_2_COMPOSITION'
WHEEL_DIR = 'research/CAS_CJT_TRANSFORMER_v0_2/artifacts/release_reproduction/dist'
WHEEL_NAMES = (
    'casformer_reference-0.1.0-py3-none-any.whl',
    'cas_neural_cjt-0.2.0-py3-none-any.whl',
)
REQUIREMENTS = 'research/CAS_META_2_COMPOSITION/requirements-gpu.txt'

INNER_RUNNER = "\n".join((
    'import hashlib',
'import json',
'import sys',
'from pathlib import Path',
'ROOT = Path(sys.argv[1])',
"sys.path.insert(0, str(ROOT / 'research/CAS_META_2_COMPOSITION'))",
'from cas_meta2.graph_teaching import (adapter, curriculum, final_panel,',
'                                      trainer, curriculum_experiment)',
'from cas_meta2.graph_teaching.real_framework import build_encoder',
'from cas_meta2.teaching_cycle import gpu_adapter',
"config = json.loads((ROOT / 'config.json').read_bytes())",
"job = config['job']",
'torch, device = gpu_adapter._cuda()',
'# Frozen candidate: the SAME teaching records and encoder as before. The',
'# final panel and the varied curriculum never enter tokenizer fitting.',
'records = trainer.training_records(20260909)',
"publics = [adapter.public_records(r, 'cas')['public'] for r in records]",
'encoder = build_encoder(torch, publics, d_model=64, seed=20260909,',
'                       device=device)',
"tasks = [adapter.public_records(record, 'cas') for record in records]",
'panel = final_panel.build_final_panel()',
"checkpoint_dir = ROOT / 'results' / 'checkpoints'",
'report = curriculum_experiment.launch(',
'    run_id=job, torch=torch, device=device, encoder=encoder,',
'    tasks=tasks, panel=panel, checkpoint_dir=checkpoint_dir)',
"report['job'] = job",
"raw = (json.dumps(report, sort_keys=True, indent=2) + '\\n').encode('utf-8')",
"results = ROOT / 'results'",
'results.mkdir(exist_ok=True)',
"(results / 'result.json').write_bytes(raw)",
"(results / 'result.json.sha256').write_text(hashlib.sha256(raw).hexdigest() + '\\n')",
'# Stage the real checkpoint files and their manifest INSIDE results/.',
"# Uploading is the OUTER worker's job: it runs with the system python, so",
"# the training venv needs no AWS SDK (attempt 003 died on 'import boto3'",
'# at the very end, after the whole run had already succeeded).',
"artifacts_dir = results / 'artifacts'",
'artifacts_dir.mkdir(exist_ok=True)',
'manifest = []',
"for artifact in report['artifacts']:",
"    path = Path(artifact['path'])",
'    body = path.read_bytes()',
'    (artifacts_dir / path.name).write_bytes(body)',
"    manifest.append({'name': path.name, 'bytes': len(body),",
"                     'sha256': hashlib.sha256(body).hexdigest(),",
"                     'step': artifact['step'],",
"                     'condition': artifact['condition'],",
"                     'learner_seed': artifact['learner_seed']})",
"(artifacts_dir / 'manifest.json').write_text(",
"    json.dumps({'artifacts': manifest}, sort_keys=True, indent=2) + '\\n')"
))

def run_checked(argv):
    subprocess.run(argv, check=True)

def upload_results(s3, bucket, results):
    """Upload staged checkpoints and THEN the result.

    Runs in the OUTER worker (system python, which has the AWS SDK), so the
    training venv needs no boto3. result.json is uploaded LAST: the launcher
    polls for it, so its presence means every artifact is already there."""
    uploaded = {'result': False, 'manifest': False, 'artifacts': []}
    if (results / 'result_partial.json').exists():
        s3.put_object(Bucket=bucket, Key='results/result_partial.json',
                      Body=(results / 'result_partial.json').read_bytes())
    if (results / 'failure.json').exists():
        s3.put_object(Bucket=bucket, Key='results/failure.json',
                      Body=(results / 'failure.json').read_bytes())
    artifacts_dir = results / 'artifacts'
    manifest_path = artifacts_dir / 'manifest.json'
    if manifest_path.exists():
        s3.put_object(Bucket=bucket, Key='results/artifacts/manifest.json',
                      Body=manifest_path.read_bytes())
        uploaded['manifest'] = True
        for entry in json.loads(manifest_path.read_text())['artifacts']:
            path = artifacts_dir / entry['name']
            if path.exists():
                s3.put_object(Bucket=bucket,
                              Key='results/artifacts/' + entry['name'],
                              Body=path.read_bytes())
                uploaded['artifacts'].append(entry['name'])
    for name in ('result.json.sha256', 'result.json'):
        path = results / name
        if path.exists():
            s3.put_object(Bucket=bucket, Key='results/' + name,
                          Body=path.read_bytes())
            uploaded['result'] = True
    return uploaded

def main():
    root = Path(__file__).resolve().parent
    config = json.loads((root / 'config.json').read_bytes())
    job = config['job']
    bucket = config['bucket']
    region = config['region']
    results = root / 'results'
    results.mkdir(exist_ok=True)
    failure = None
    try:
        venv = root / 'venv'
        venv_py = venv / 'bin' / 'python'
        if not venv_py.exists():
            base = next((c for c in ('python3.12', 'python3.11', 'python3')
                         if shutil.which(c)), None)
            if base is None:
                raise SystemExit('SUPPORTED_PYTHON_REQUIRED')
            run_checked([base, '-m', 'venv', str(venv)])
        python = str(venv_py)
        run_checked([python, '-m', 'pip', 'install', '--disable-pip-version-check',
                     'torch==2.11.0', '--index-url', TORCH_INDEX])
        wheels = [str(root / WHEEL_DIR / name) for name in WHEEL_NAMES]
        run_checked([python, '-m', 'pip', 'install', '--disable-pip-version-check',
                     '--no-deps', *wheels])
        run_checked([python, '-m', 'pip', 'install', '--disable-pip-version-check',
                     '-r', str(root / REQUIREMENTS)])
        runner = root / '_inner_runner.py'
        runner.write_text(INNER_RUNNER)
        inner = subprocess.run([python, '-B', str(runner), str(root)],
                             capture_output=True, text=True,
                             timeout=MAX_WALL_SECONDS * LEARNERS + 2400)
        if inner.returncode != 0:
            detail = (inner.stderr or inner.stdout or '')[-1800:]
            failure = {'type': 'InnerRunnerFailure',
                       'message': 'INNER_RUNNER_EXIT_' + str(inner.returncode)
                                  + '\n' + detail}
        raw = (results / 'result.json').read_bytes()
        sidecar = (results / 'result.json.sha256').read_text().strip()
        if hashlib.sha256(raw).hexdigest() != sidecar:
            failure = failure or {'type': 'ResultMismatch',
                                  'message': 'RESULT_SHA_MISMATCH'}
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)[:2000]}
    if failure is not None:
        # NEVER destroy a result the run already produced: keep it, and record
        # the failure beside it (attempt 003 lost a completed run this way).
        existing = results / 'result.json'
        if existing.exists():
            preserved = existing.read_bytes()
            (results / 'result_partial.json').write_bytes(preserved)
            (results / 'result_partial.json.sha256').write_text(
                hashlib.sha256(preserved).hexdigest() + '\n')
        else:
            report = {'schema': 'cas-graph-training-curriculum-result/1',
                      'status': 'REMOTE_WORKER_FAILED', 'failure': failure,
                      'job': job}
            raw = (json.dumps(report, sort_keys=True, indent=2) + '\n').encode('utf-8')
            existing.write_bytes(raw)
            (results / 'result.json.sha256').write_text(
                hashlib.sha256(raw).hexdigest() + '\n')
        (results / 'failure.json').write_text(
            json.dumps(failure, sort_keys=True, indent=2) + '\n')
    import boto3
    s3 = boto3.client('s3', region_name=region)
    upload_results(s3, bucket, results)

if __name__ == '__main__':
    main()
