#!/usr/bin/env python3
"""Binding-fit training worker for the teaching campaign. One run, no restart.

Rendered into the source package by aws/binding_fit_launch.render_worker().
Reads job/bucket/region from config.json, creates (or discovers) the isolated
task venv, installs torch==2.11.0 from the cu128 index and the two frozen
wheels with --no-deps, runs the real cas_meta2.binding_fit_training.mode.launch,
writes results/result.json plus a sha256 sidecar, and uploads both to the job
bucket. Evidence is written on failure too.
"""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

MAX_OPTIMIZER_STEPS = 48
MAX_WALL_SECONDS = 600.0
LEARNING_RATE = 0.003
TORCH_INDEX = 'https://download.pytorch.org/whl/cu128'
PILOT = 'research/CAS_META_2_COMPOSITION'
WHEEL_DIR = 'research/CAS_CJT_TRANSFORMER_v0_2/artifacts/release_reproduction/dist'
WHEEL_NAMES = (
    'casformer_reference-0.1.0-py3-none-any.whl',
    'cas_neural_cjt-0.2.0-py3-none-any.whl',
)
REQUIREMENTS = 'research/CAS_META_2_COMPOSITION/requirements-gpu.txt'

INNER_RUNNER = "\n".join((
    'import hashlib',
'import json',
'import sys',
'from pathlib import Path',
'ROOT = Path(sys.argv[1])',
"sys.path.insert(0, str(ROOT / 'research/CAS_META_2_COMPOSITION'))",
'from cas_meta2.binding_fit_training import mode',
"config = json.loads((ROOT / 'config.json').read_bytes())",
"job = config['job']",
'report = mode.launch(run_id=job, max_optimizer_steps=48, max_wall_seconds=600.0, learning_rate=0.003)',
"raw = (json.dumps(report, sort_keys=True, indent=2) + '\\n').encode('utf-8')",
"results = ROOT / 'results'",
'results.mkdir(exist_ok=True)',
"(results / 'result.json').write_bytes(raw)",
"(results / 'result.json.sha256').write_text(hashlib.sha256(raw).hexdigest() + '\\n')"
))

def run_checked(argv):
    subprocess.run(argv, check=True)

def main():
    root = Path(__file__).resolve().parent
    config = json.loads((root / 'config.json').read_bytes())
    job = config['job']
    bucket = config['bucket']
    region = config['region']
    results = root / 'results'
    results.mkdir(exist_ok=True)
    try:
        venv = root / 'venv'
        venv_py = venv / 'bin' / 'python'
        if not venv_py.exists():
            base = next((c for c in ('python3.12', 'python3.11', 'python3')
                         if shutil.which(c)), None)
            if base is None:
                raise SystemExit('SUPPORTED_PYTHON_REQUIRED')
            run_checked([base, '-m', 'venv', str(venv)])
        python = str(venv_py)
        run_checked([python, '-m', 'pip', 'install', '--disable-pip-version-check',
                     'torch==2.11.0', '--index-url', TORCH_INDEX])
        wheels = [str(root / WHEEL_DIR / name) for name in WHEEL_NAMES]
        run_checked([python, '-m', 'pip', 'install', '--disable-pip-version-check',
                     '--no-deps', *wheels])
        run_checked([python, '-m', 'pip', 'install', '--disable-pip-version-check',
                     '-r', str(root / REQUIREMENTS)])
        runner = root / '_inner_runner.py'
        runner.write_text(INNER_RUNNER)
        inner = subprocess.run([python, '-B', str(runner), str(root)],
                             capture_output=True, text=True,
                             timeout=MAX_WALL_SECONDS + 1200)
        if inner.returncode != 0:
            detail = (inner.stderr or inner.stdout or '')[-1800:]
            raise SystemExit('INNER_RUNNER_EXIT_' + str(inner.returncode) + '\n' + detail)
        raw = (results / 'result.json').read_bytes()
        sidecar = (results / 'result.json.sha256').read_text().strip()
        if hashlib.sha256(raw).hexdigest() != sidecar:
            raise SystemExit('RESULT_SHA_MISMATCH')
    except BaseException as error:
        failure = {'type': type(error).__name__, 'message': str(error)[:2000]}
        report = {'schema': 'cas-teaching-binding-fit-training/1',
                  'status': 'REMOTE_WORKER_FAILED', 'failure': failure, 'run_id': job}
        raw = (json.dumps(report, sort_keys=True, indent=2) + '\n').encode('utf-8')
        (results / 'result.json').write_bytes(raw)
        (results / 'result.json.sha256').write_text(hashlib.sha256(raw).hexdigest() + '\n')
    import boto3
    s3 = boto3.client('s3', region_name=region)
    s3.put_object(Bucket=bucket, Key='results/result.json',
                  Body=(results / 'result.json').read_bytes())
    s3.put_object(Bucket=bucket, Key='results/result.json.sha256',
                  Body=(results / 'result.json.sha256').read_bytes())

if __name__ == '__main__':
    main()
