"""Validate planning counters and portable-file integrity only. No neural or repository execution."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def canonical_report(value: object) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False, sort_keys=True) + "\n"


def planning_report(root: Path) -> dict:
    profile = json.loads((root / 'Complementary_Teaching_Profile_v0.1.json').read_text(encoding='utf-8'))
    rows = [json.loads(line) for line in (root / 'Reference_Batch_Schedule.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    require(profile['execution_enabled'] is False and profile['owner_execution_approved'] is False, 'This handoff must remain execution-disabled.')
    require(profile['training']['adaptive_reallocation_enabled'] is False, 'The reference experiment uses fixed alternation.')
    require(all(row['record_kind'] == 'PLANNED_BATCH_SLOT' and row['actual_execution'] is False for row in rows), 'Schedule slots must not masquerade as executed lessons.')

    groups = defaultdict(list)
    for row in rows:
        groups[(row['training_seed'], row['condition'])].append(row)
    seeds = profile['training']['paired_training_seeds']
    conditions = profile['training']['conditions']
    require(set(groups) == {(s,c) for s in seeds for c in conditions}, 'Missing or extra course.')

    totals = Counter()
    per_course = []
    for (seed, condition), course in sorted(groups.items()):
        require([row['planned_update_index'] for row in course] == list(range(1,161)), 'Global planned update cursor is discontinuous.')
        base = profile['training']['base_round_depths']
        offset = profile['training']['depth_rotation_offsets'][str(seed)]
        expected_depths = base[offset:] + base[:offset]
        require(Counter(expected_depths) == {1:4,2:4,4:4,8:4}, 'Unbalanced recurrence schedule.')
        readings = {
            'decision_presentations': sum(row['batch_size'] for row in course),
            'optimizer_updates': len(course),
            'batch_core_forward_calls': sum(row['depth'] for row in course),
            'sample_core_passes': sum(row['depth']*row['batch_size'] for row in course),
        }
        require(readings == {'decision_presentations':1152,'optimizer_updates':160,'batch_core_forward_calls':600,'sample_core_passes':4320}, 'Incorrect course arithmetic.')
        for r in range(1,17):
            block = [row for row in course if row['round'] == r]
            require(len(block)==10 and sum(row['batch_size'] for row in block)==72, 'Incomplete enhanced round.')
            require([row['batch_in_round'] for row in block]==list(range(1,11)), 'Batch order mismatch.')
            require(all(row['depth']==expected_depths[r-1] for row in block), 'Mode/depth confound.')
            require([row['batch_size'] for row in block]==[8,8,8,4,8,4,8,8,8,8], 'Unexpected partial-batch or phase schedule.')
            require([row['phase'] for row in block[:7]]==['WITHIN_CUBE']*4+['ACROSS_FACE']*2+['RETURN_TO_CUBE'], 'CFC foundation changed.')
            require(block[-1]['phase']=='MAINTENANCE', 'Maintenance must follow supplementary practice.')
            require(all(len(row['slots'])==row['batch_size'] for row in block), 'Batch size disagrees with slot list.')
            require(all(len(set(row['slots']))==len(row['slots']) for row in block), 'Duplicate within a planned batch.')
        totals.update(readings)
        per_course.append({'condition':condition,'training_seed':seed,'planned':readings})

    for seed in seeds:
        for r in range(1,17):
            block = {c:[row for row in groups[(seed,c)] if row['round']==r] for c in conditions}
            alt = block['ALT_COMPONENT_WHOLE']
            mixed = block['MIXED_SAME_ITEMS']
            whole = block['WHOLE_SUPPLEMENT']
            for index in list(range(7))+[9]:
                require(alt[index]['slots']==mixed[index]['slots']==whole[index]['slots'], 'Common foundation/maintenance differs across conditions.')
            alt_slots = alt[7]['slots'] + alt[8]['slots']
            mix_slots = mixed[7]['slots'] + mixed[8]['slots']
            require(Counter(alt_slots)==Counter(mix_slots), 'ALT/MIXED supplemental multisets differ.')
            require(all('/A/' in x for x in alt[7]['slots']) and all('/B/' in x for x in alt[8]['slots']), 'ALT is not component-then-whole.')
            for row in mixed[7:9]:
                require(sum('/A/' in x for x in row['slots'])==4 and sum('/B/' in x for x in row['slots'])==4, 'MIXED is not 4/4 per batch.')
            require(whole[7]['slots']==whole[8]['slots']==alt[8]['slots'], 'WHOLE control does not repeat the exact B set.')

    total_dict = dict(totals)
    require(total_dict=={'decision_presentations':10368,'optimizer_updates':1440,'batch_core_forward_calls':5400,'sample_core_passes':38880}, 'Incorrect nine-course totals.')
    require(1+len(profile['monitoring']['rounds'])*len(profile['monitoring']['points'])==17, 'Monitor snapshot count wrong.')
    return {
        'status':'HANDOFF_PLANNING_ARITHMETIC_CHECKED',
        'implementation_id':profile['implementation_id'],
        'conditions':conditions,
        'planned_courses':len(groups),
        'planned_batch_rows':len(rows),
        'per_course':per_course,
        'all_courses_planned':total_dict,
        'checks':{
            'preserved_cfc_foundation_and_maintenance':True,
            'continuous_planned_course_cursor':True,
            'alt_mixed_same_supplemental_slot_multisets':True,
            'whole_control_exact_b_repetition':True,
            'all_modes_same_round_depth':True,
            'one_update_per_planned_batch':True,
            'partial_batches_preserved':True,
            'monitor_snapshots_per_course':17,
            'execution_disabled':True,
        },
        'actual':{'neural_presentations':0,'optimizer_updates':0,'provider_calls':0,'repository_tests_run':0},
        'limits':[
            'Counts are proposed schedule arithmetic, not performed computation.',
            'Slot references are not real checked lessons or semantic question identities.',
            'No repository, model, reference checker, learner adapter, or CUDA behavior was validated.',
            'No learning, retention, curriculum advantage, or current cloud state is established.',
        ],
    }


def verify_manifest(root: Path) -> None:
    manifest = json.loads((root/'HANDOFF_MANIFEST.json').read_text(encoding='utf-8'))
    expected = {row['path'] for row in manifest['artifacts']}
    actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='HANDOFF_MANIFEST.json' and '__pycache__' not in p.parts}
    require(expected == actual, 'Manifest membership mismatch.')
    for row in manifest['artifacts']:
        relative = Path(row['path'])
        require(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe manifest path.')
        data=(root/relative).read_bytes()
        require(len(data)==row['bytes'], 'File byte count mismatch: '+row['path'])
        require(hashlib.sha256(data).hexdigest()==row['sha256'], 'File hash mismatch: '+row['path'])


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write-report', action='store_true', help='Write the deterministic local planning report. Not a model execution.')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    report=planning_report(root)
    text=canonical_report(report)
    report_path=root/'Handoff_Check.json'
    if args.write_report:
        if report_path.exists():
            require(report_path.read_text(encoding='utf-8')==text, 'Existing planning report differs; do not overwrite silently.')
        else:
            report_path.write_text(text, encoding='utf-8')
    else:
        require(report_path.read_text(encoding='utf-8')==text, 'Stored planning report does not reproduce.')
    manifest_present=(root/'HANDOFF_MANIFEST.json').exists()
    if manifest_present:
        verify_manifest(root)
    else:
        require(args.write_report, 'Missing handoff manifest.')
    print(json.dumps({'planning_check':'PASS','manifest_verified':manifest_present,'planned_courses':report['planned_courses'],'actual_neural_updates':0},sort_keys=True))


if __name__=='__main__':
    main()
