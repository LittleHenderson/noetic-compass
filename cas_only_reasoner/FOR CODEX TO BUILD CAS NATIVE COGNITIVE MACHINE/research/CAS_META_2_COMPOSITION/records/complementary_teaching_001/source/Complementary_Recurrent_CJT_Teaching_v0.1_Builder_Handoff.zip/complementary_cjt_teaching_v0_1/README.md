# Builder handoff: CAS_COMPLEMENTARY_TEACHING_001

Read **Complementary_CJT_Teaching_Directive_v0.1.md** first. The JSON is the proposed profile, and the JSONL expands its nine planned courses into batch slots. These are not actual lesson records, predictions, or a ready-to-launch source package.

The change is an opt-in teaching extension, not a replacement for the ongoing CAS_RDCJT_001 build. It preserves the full CFC foundation and adds a component/whole practice unit before maintenance. All conditions use the same recurrent architecture; the same learner and optimizer continue across modes.

Complete ordinary non-neural implementation, real dependency bindings, existing tests, opt-in worker dispatch and packaging as one assignment. Return one runnable candidate and one unsigned, costed request. Do not pause the current experiment or spend/execute neural code under this document.

## Files

- `Complementary_CJT_Teaching_Directive_v0.1.md`: implementation scope, schedule, experiment, boundaries and completion target.
- `Complementary_Teaching_Profile_v0.1.json`: proposed machine-readable configuration; unbound runtime identities and cost fields are null.
- `Reference_Batch_Schedule.jsonl`: planned batch slots only, not semantic question identities or labels. Bind them to checked actual examples during the build.
- `verify_handoff.py`: standard-library checker for this handoff's counters, matching controls and manifest. No repository or neural imports.
- `Handoff_Check.json`: output of that checker, not a model result.
- `HANDOFF_MANIFEST.json`: artifact and available source identities. The original source papers/specifications are not copied into this package.

Run the portable handoff check with:

```text
python verify_handoff.py
```

The check does not validate the repository's runtime, the teacher, CUDA, learning, retention, or the hypothesis of complementary benefits. Build-ready is a later repository state, not a status awarded to these planning files.
