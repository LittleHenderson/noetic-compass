//! TODO: Implement inversions module
