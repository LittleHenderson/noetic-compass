#!/usr/bin/env python3
"""Merge Stage 9 40E proof reports into an Evidence Packet.

The merger refuses to invent ACCEPT/SUPPRESS. It can emit a final verdict only
when all required proof tiers are present and a separate verifier report carries
an explicit decision.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "cas_harness_stage9_40e_evidence_packet.v1"
METHOD_LABEL = "S9-40E-ORIGINAL-BASELINE-READOUT"
DEFAULT_READOUT_REPORT = (
    Path(__file__).resolve().parents[2]
    / "docs"
    / "working"
    / "gpt_neox_20b_stage9_original_40e_probe_eval_report_20260527.json"
)
DEFAULT_OUTPUT_JSON = (
    Path(__file__).resolve().parents[2]
    / "docs"
    / "working"
    / "gpt_neox_20b_stage9_original_40e_evidence_packet_20260527.json"
)
DEFAULT_OUTPUT_MARKDOWN = DEFAULT_OUTPUT_JSON.with_suffix(".md")

CORRECTED_BASELINE = {
    "hidden_probe_test_acc": 0.95625,
    "hidden_probe_test_acc_pct": 95.625,
    "confirmed_text_test_acc": 0.4924107142857143,
    "confirmed_text_test_acc_pct": 49.241071,
    "text_hash_test_acc": 0.5,
    "text_hash_test_acc_pct": 50.0,
    "shuffled_label_hidden_mean_test_acc": 0.02619419642857143,
    "shuffled_label_hidden_mean_test_acc_pct": 2.619,
    "compact_gloss_v0_text_only_acc": 1.0,
    "compact_gloss_v0_text_only_acc_pct": 100.0,
}

REVIEW_VERDICT = "FLAG_FOR_HUMAN_REVIEW"
FINAL_VERDICTS = {"ACCEPT", "SUPPRESS", "FLAG_FOR_HUMAN_REVIEW"}
PASSING_PROOF_STATUSES = {"present", "verified"}
PASSING_UNIQUENESS_STATUSES = {
    "matched_taxonomy_validated",
    "uniqueness_validated",
    "condition3_validated",
    "condition_3_validated",
    "passed",
    "verified",
}
REQUIRED_PROOF_CHIPS = (
    "model_proof",
    "cas_readout",
    "causal_proof",
    "control_proof",
    "output_proof",
    "packet_proof",
)
STRICT_VERIFIED_PROOF_CHIPS = (
    "cas_readout",
    "causal_proof",
    "control_proof",
    "output_proof",
)
PROOF_CHIP_NAMES = {
    "model_proof": "Model proof",
    "cas_readout": "CAS readout",
    "causal_proof": "Causal proof",
    "control_proof": "Control proof",
    "output_proof": "Output proof",
    "packet_proof": "Packet proof",
}
INPUT_COPY_KEYS = (
    "schema_version",
    "status",
    "created_at",
    "model_id",
    "model_name",
    "model_family",
    "model_scale",
    "parameter_scale",
    "dataset",
    "metadata_path",
    "method_label",
    "method_contract",
    "run_id",
    "trace_id",
    "artifacts",
    "hashes",
    "provenance",
)


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SystemExit(f"required report does not exist: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SystemExit(f"report is not valid JSON: {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise SystemExit(f"report must be a JSON object: {path}")
    return payload


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _report_artifact(path: Path, artifact_id: str, artifact_type: str) -> dict[str, Any]:
    stat = path.stat()
    return {
        "artifact_id": artifact_id,
        "artifact_type": artifact_type,
        "content_sha256": _sha256_file(path),
        "byte_count": int(stat.st_size),
        "storage_uri": str(path),
        "redaction_class": "stage9_40e_internal_report",
        "created_at": datetime.fromtimestamp(stat.st_mtime, UTC).isoformat(),
    }


def _copy_known_fields(report: dict[str, Any]) -> dict[str, Any]:
    return {key: report[key] for key in INPUT_COPY_KEYS if key in report}


def _nested_get(report: dict[str, Any], path: tuple[str, ...]) -> Any:
    current: Any = report
    for key in path:
        if not isinstance(current, dict) or key not in current:
            return None
        current = current[key]
    return current


def _first_present(report: dict[str, Any], paths: tuple[tuple[str, ...], ...]) -> Any:
    for path in paths:
        value = _nested_get(report, path)
        if value is not None:
            return value
    return None


def _numeric_close(left: Any, right: float, tolerance: float = 1e-9) -> bool | None:
    if left is None:
        return None
    try:
        return abs(float(left) - right) <= tolerance
    except (TypeError, ValueError):
        return False


def _observed_baseline_fields(readout: dict[str, Any]) -> dict[str, Any]:
    """Pull known metric locations without requiring one exact report schema."""
    return {
        "hidden_probe_test_acc": _first_present(
            readout,
            (
                ("corrected_baseline", "hidden_probe_test_acc"),
                ("baseline", "hidden_probe_test_acc"),
                ("baseline_proof", "hidden_probe_test_acc"),
                ("result_summary", "hidden_probe_test_acc"),
                ("best_layer", "test_acc"),
            ),
        ),
        "confirmed_text_test_acc": _first_present(
            readout,
            (
                ("corrected_baseline", "confirmed_text_test_acc"),
                ("baseline", "confirmed_text_test_acc"),
                ("baseline_proof", "confirmed_text_test_acc"),
                ("controls", "confirmed_text_baseline_report", "test_acc"),
                ("controls", "confirmed_text", "test_acc"),
                ("controls", "confirmed_text_baseline", "test_acc"),
                ("controls", "confirmed_text_test_acc"),
            ),
        ),
        "text_hash_test_acc": _first_present(
            readout,
            (
                ("corrected_baseline", "text_hash_test_acc"),
                ("baseline", "text_hash_test_acc"),
                ("baseline_proof", "text_hash_test_acc"),
                ("controls", "text_hash_baseline", "test_acc"),
                ("controls", "text_hash_centroid", "test_acc"),
                ("controls", "text_hash", "test_acc"),
                ("controls", "text_hash_test_acc"),
            ),
        ),
        "shuffled_label_hidden_mean_test_acc": _first_present(
            readout,
            (
                ("corrected_baseline", "shuffled_label_hidden_mean_test_acc"),
                ("baseline", "shuffled_label_hidden_mean_test_acc"),
                ("baseline_proof", "shuffled_label_hidden_mean_test_acc"),
                ("controls", "shuffled_label_hidden_best_layer", "mean_test_acc"),
                ("controls", "shuffled_label_hidden", "mean_test_acc"),
                ("controls", "shuffled_label_mean_test_acc"),
            ),
        ),
        "compact_gloss_v0_text_only_acc": _first_present(
            readout,
            (
                ("corrected_baseline", "compact_gloss_v0_text_only_acc"),
                ("baseline", "compact_gloss_v0_text_only_acc"),
                ("baseline_proof", "compact_gloss_v0_text_only_acc"),
                ("controls", "compact_gloss_v0", "text_only_acc"),
                ("compact_gloss_v0", "text_only_acc"),
            ),
        ),
        "compact_gloss_v0_status": _first_present(
            readout,
            (
                ("corrected_baseline", "compact_gloss_v0_status"),
                ("baseline", "compact_gloss_v0_status"),
                ("baseline_proof", "compact_gloss_v0_status"),
                ("controls", "compact_gloss_v0", "status"),
                ("compact_gloss_v0", "status"),
            ),
        ),
    }


def _baseline_checks(observed: dict[str, Any]) -> dict[str, str]:
    checks: dict[str, str] = {}
    for key in (
        "hidden_probe_test_acc",
        "confirmed_text_test_acc",
        "text_hash_test_acc",
        "shuffled_label_hidden_mean_test_acc",
        "compact_gloss_v0_text_only_acc",
    ):
        expected = CORRECTED_BASELINE[key]
        result = _numeric_close(observed.get(key), expected)
        if result is True:
            checks[key] = "matches_corrected_baseline"
        elif result is False:
            checks[key] = "differs_from_corrected_baseline"
        else:
            checks[key] = "not_present_in_source_report"

    status = observed.get("compact_gloss_v0_status")
    if status is None:
        checks["compact_gloss_v0_status"] = "not_present_in_source_report"
    elif str(status).lower() in {"blocked", "blocked_text_only", "text_only_blocked"}:
        checks["compact_gloss_v0_status"] = "matches_corrected_baseline"
    else:
        checks["compact_gloss_v0_status"] = "differs_from_corrected_baseline"
    return checks


def _extract_trace_id(readout: dict[str, Any]) -> str:
    explicit = _first_present(
        readout,
        (
            ("trace_id",),
            ("run", "trace_id"),
            ("provenance", "trace_id"),
            ("metadata", "trace_id"),
        ),
    )
    if explicit:
        return str(explicit)
    return "stage9-40e-original-baseline-readout-20260527"


def _extract_run_id(readout: dict[str, Any]) -> str:
    explicit = _first_present(
        readout,
        (
            ("run_id",),
            ("run", "run_id"),
            ("provenance", "run_id"),
            ("metadata", "run_id"),
        ),
    )
    if explicit:
        return str(explicit)
    return "gpt-neox-20b-stage9-original-40e-20260527"


def _extract_model_proof(
    readout: dict[str, Any],
    readout_artifact: dict[str, Any],
    parameter_scale_override: str | None = None,
) -> dict[str, Any]:
    model_id = _first_present(
        readout,
        (
            ("model_id",),
            ("model", "model_id"),
            ("model_subject", "model_id"),
            ("provenance", "model_id"),
        ),
    )
    model_weight_hash = _first_present(
        readout,
        (
            ("model_weight_hash",),
            ("hashes", "model_weight_hash"),
            ("hashes", "weights_sha"),
            ("model_subject", "model_weight_hash"),
            ("provenance", "model_weight_hash"),
        ),
    )
    return {
        "status": "present",
        "model_id": model_id or "EleutherAI/gpt-neox-20b",
        "model_family": _first_present(
            readout,
            (
                ("model_family",),
                ("model", "model_family"),
                ("model_subject", "model_family"),
            ),
        )
        or "gpt_neox",
        "parameter_scale": parameter_scale_override
        or _first_present(
            readout,
            (
                ("parameter_scale",),
                ("model_scale",),
                ("model", "parameter_scale"),
                ("model_subject", "parameter_scale"),
            ),
        )
        or "20B",
        "model_weight_hash": model_weight_hash,
        "source_report": readout_artifact,
        "input_provenance": readout.get("provenance"),
    }


def _make_readout_proof(
    readout: dict[str, Any],
    readout_artifact: dict[str, Any],
) -> dict[str, Any]:
    return {
        "status": "present",
        "method_label": METHOD_LABEL,
        "source_report": readout_artifact,
        "source_fields": _copy_known_fields(readout),
        "best_layer": readout.get("best_layer"),
        "controls": readout.get("controls"),
        "result_summary": readout.get("result_summary"),
        "readiness_gate": readout.get("readiness_gate"),
        "baseline_note": (
            "PR #102 corrected the Stage 9 original 40E readout baseline. "
            "This merger preserves that corrected baseline and does not promote "
            "the packet to ACCEPT or SUPPRESS."
        ),
    }


def _make_baseline_proof(readout: dict[str, Any]) -> dict[str, Any]:
    observed = _observed_baseline_fields(readout)
    return {
        "status": "present",
        "method_label": METHOD_LABEL,
        **CORRECTED_BASELINE,
        "compact_gloss_v0": {
            "status": "blocked_text_only",
            "text_only_acc": CORRECTED_BASELINE["compact_gloss_v0_text_only_acc"],
            "text_only_acc_pct": CORRECTED_BASELINE["compact_gloss_v0_text_only_acc_pct"],
            "note": "compact-gloss v0 is blocked because it is 100% text-only.",
        },
        "observed_source_fields": observed,
        "source_field_checks": _baseline_checks(observed),
        "source": "PR #102 corrected 20B Stage 9 original 40E readout",
    }


def _pct(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return round(float(value) * 100.0, 6)
    except (TypeError, ValueError):
        return None


def _make_report_summary(tier_name: str, report: dict[str, Any]) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "status": report.get("status"),
        "method_label": report.get("method_label"),
        "run_id": report.get("run_id"),
        "trace_id": report.get("trace_id"),
    }

    if tier_name == "subspace_ablation":
        primary = report.get("primary_result")
        if isinstance(primary, dict):
            summary["primary_result"] = {
                "layer": primary.get("layer"),
                "original_accuracy": primary.get("original_accuracy"),
                "original_accuracy_pct": _pct(primary.get("original_accuracy")),
                "ablated_accuracy": primary.get("ablated_accuracy"),
                "ablated_accuracy_pct": _pct(primary.get("ablated_accuracy")),
                "true_disruption": primary.get("true_disruption"),
                "true_disruption_pp": _pct(primary.get("true_disruption")),
                "chance_baseline_accuracy": primary.get("chance_baseline_accuracy"),
                "chance_baseline_accuracy_pct": _pct(
                    primary.get("chance_baseline_accuracy")
                ),
                "random_same_rank_mean_disruption": primary.get(
                    "random_same_rank_mean_disruption"
                ),
                "random_same_rank_mean_disruption_pp": _pct(
                    primary.get("random_same_rank_mean_disruption")
                ),
                "random_same_rank_max_disruption": primary.get(
                    "random_same_rank_max_disruption"
                ),
                "random_same_rank_max_disruption_pp": _pct(
                    primary.get("random_same_rank_max_disruption")
                ),
                "guard_status": primary.get("guard_status"),
            }

    if tier_name == "cover_discovery":
        cover_map = report.get("cover_map")
        true_cover_per_class = report.get("true_cover_per_class")
        matched_controls = report.get("matched_controls")
        if isinstance(cover_map, dict):
            summary["class_count"] = len(cover_map)
        elif isinstance(true_cover_per_class, dict):
            summary["class_count"] = len(true_cover_per_class)
        summary["selected_layer"] = report.get("selected_layer")
        summary["top_k"] = report.get("top_k")
        if isinstance(true_cover_per_class, dict):
            summary["true_cover_classes"] = len(true_cover_per_class)
        if isinstance(matched_controls, dict):
            summary["matched_controls"] = {
                "random_same_size_classes": len(
                    matched_controls.get("random_same_size") or {}
                )
                if isinstance(matched_controls.get("random_same_size"), dict)
                else None,
                "wrong_class_reference_classes": len(
                    matched_controls.get("wrong_class_references") or {}
                )
                if isinstance(matched_controls.get("wrong_class_references"), dict)
                else None,
            }
        if "caveat" in report:
            summary["caveat"] = report["caveat"]

    if tier_name == "output_bridge":
        key_comparisons = report.get("key_comparisons")
        bridge_gates = report.get("bridge_gates")
        probe_prediction = report.get("probe_prediction")
        if isinstance(key_comparisons, dict):
            summary["key_comparisons"] = key_comparisons
        if isinstance(bridge_gates, dict):
            summary["bridge_gates"] = bridge_gates
            summary["probe_readable_gate_passed"] = bool(
                bridge_gates.get("probe_readable", {}).get("passed")
            )
            summary["gold_readable_gate_passed"] = bool(
                bridge_gates.get("gold_readable", {}).get("passed")
            )
        if isinstance(probe_prediction, dict):
            summary["probe_prediction"] = {
                "selected_element_accuracy": probe_prediction.get(
                    "selected_element_accuracy"
                ),
                "selected_operator_accuracy": probe_prediction.get(
                    "selected_operator_accuracy"
                ),
                "selected_domain_accuracy": probe_prediction.get(
                    "selected_domain_accuracy"
                ),
                "all_test_element_accuracy": probe_prediction.get(
                    "all_test_element_accuracy"
                ),
            }
        for key in ("n_cases", "per_element", "readout_layer", "readout_mode"):
            if key in report:
                summary[key] = report[key]
        if "implication" in report:
            summary["implication"] = report["implication"]

    if tier_name == "matched_taxonomy":
        source_summary = _mapping_or_empty(report.get("summary"))
        for key in (
            "condition3_passed",
            "condition_3_passed",
            "matched_taxonomy_gate_passed",
            "uniqueness_gate_passed",
            "control_b_passed",
            "control_c_passed",
            "reason",
        ):
            if key in report:
                summary[key] = report[key]
            elif key in source_summary:
                summary[key] = source_summary[key]
        for key in ("control_b", "control_c"):
            value = report.get(key, source_summary.get(key))
            if isinstance(value, dict):
                summary[key] = {
                    "status": value.get("status"),
                    "passed": value.get("passed"),
                    "reason": value.get("reason"),
                }

    return summary


def _make_optional_proof(
    *,
    tier_name: str,
    report_path: Path | None,
    artifact_id: str,
    artifact_type: str,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    if report_path is None:
        return (
            {
                "status": "missing",
                "tier": tier_name,
                "required_for_final_verdict": True,
                "source_report": None,
                "blocking_reason": f"{tier_name} report was not supplied",
            },
            None,
        )

    report = _load_json(report_path)
    artifact = _report_artifact(report_path, artifact_id, artifact_type)
    return (
        {
            "status": "present",
            "tier": tier_name,
            "required_for_final_verdict": True,
            "source_report": artifact,
            "source_fields": _copy_known_fields(report),
            "summary": _make_report_summary(tier_name, report),
        },
        artifact,
    )


def _confidence_or_none(value: Any) -> float | None:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return None
    out = float(value)
    if not 0.0 <= out <= 1.0:
        return None
    return out


def _mapping_or_empty(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _extract_explicit_decision(report: dict[str, Any]) -> dict[str, Any] | None:
    candidate = report
    if isinstance(report.get("explicit_verifier_decision"), dict):
        candidate = report["explicit_verifier_decision"]
    elif isinstance(report.get("verification"), dict) and isinstance(
        report["verification"].get("explicit_verifier_decision"), dict
    ):
        candidate = report["verification"]["explicit_verifier_decision"]

    verdict = candidate.get("verdict")
    confidence = _confidence_or_none(candidate.get("confidence"))
    if verdict not in FINAL_VERDICTS or confidence is None:
        return None
    return {
        "verdict": verdict,
        "confidence": confidence,
        "source": str(candidate.get("source") or report.get("source") or "stage9_40e_verifier"),
        "reason": str(candidate.get("reason") or report.get("reason") or ""),
        "mode": candidate.get("mode") or report.get("mode"),
        "coverage": candidate.get("coverage") or report.get("coverage"),
        "decision_scope": (
            candidate.get("decision_scope")
            or report.get("decision_scope")
            or "stage9_40e_validation_packet"
        ),
    }


def _make_verifier_proof(
    verifier_report: Path | None,
) -> tuple[dict[str, Any], dict[str, Any] | None, dict[str, Any] | None]:
    if verifier_report is None:
        return (
            {
                "status": "missing",
                "required_for_final_verdict": True,
                "source_report": None,
                "blocking_reason": "No verifier decision layer is attached to this packet.",
            },
            None,
            None,
        )

    report = _load_json(verifier_report)
    artifact = _report_artifact(
        verifier_report,
        "stage9_40e_verifier_report",
        "stage9_40e_verifier_decision_report",
    )
    decision = _extract_explicit_decision(report)
    if decision is None:
        return (
            {
                "status": "failed",
                "required_for_final_verdict": True,
                "source_report": artifact,
                "source_fields": _copy_known_fields(report),
                "blocking_reason": (
                    "Verifier report is present but does not carry a valid explicit "
                    "verdict plus numeric confidence in [0, 1]."
                ),
            },
            artifact,
            None,
        )

    return (
        {
            "status": "present",
            "required_for_final_verdict": True,
            "source_report": artifact,
            "source_fields": _copy_known_fields(report),
            "explicit_verifier_decision": decision,
        },
        artifact,
        decision,
    )


def _causal_chip_status(causal_proof: dict[str, Any]) -> str:
    if causal_proof.get("status") != "present":
        return "missing"
    primary = _mapping_or_empty(_mapping_or_empty(causal_proof.get("summary")).get("primary_result"))
    guard_passed = str(primary.get("guard_status")).lower() == "passed"
    disruption = primary.get("true_disruption")
    random_max = primary.get("random_same_rank_max_disruption")
    if guard_passed and isinstance(disruption, (int, float)) and isinstance(random_max, (int, float)):
        return "verified" if float(disruption) > float(random_max) else "failed"
    return "present"


def _output_chip_status(output_bridge_proof: dict[str, Any]) -> str:
    if output_bridge_proof.get("status") != "present":
        return "missing"
    summary = _mapping_or_empty(output_bridge_proof.get("summary"))
    if summary.get("probe_readable_gate_passed") is True:
        return "verified"
    if summary.get("probe_readable_gate_passed") is False:
        return "failed"
    return "present"


def _control_chip_status(control_proof: dict[str, Any]) -> str:
    if control_proof.get("status") != "present":
        return "missing"
    summary = _mapping_or_empty(control_proof.get("summary"))
    class_count = summary.get("class_count")
    if not (isinstance(class_count, int) and class_count >= 40):
        return "present"
    # Cover discovery that is still candidate-only (no matched-ablation
    # validation against random same-size and wrong-class controls) is recorded
    # evidence but is NOT verified. Having 40 candidate cover classes is not the
    # same as a validated control: a "verified" control chip requires the cover
    # report to declare that matched-ablation validation actually ran and passed.
    source_status = str(
        _mapping_or_empty(control_proof.get("source_fields")).get("status")
        or summary.get("status")
        or ""
    ).lower()
    if "candidate" in source_status:
        return "present"
    if source_status in {
        "matched_ablation_validated",
        "control_validation_completed",
        "controls_validated",
    }:
        return "verified"
    return "present"


def _readout_chip_status(baseline_proof: dict[str, Any]) -> str:
    hidden = baseline_proof.get("hidden_probe_test_acc")
    confirmed_text = baseline_proof.get("confirmed_text_test_acc")
    shuffled = baseline_proof.get("shuffled_label_hidden_mean_test_acc")
    if all(isinstance(value, (int, float)) for value in (hidden, confirmed_text, shuffled)):
        if float(hidden) > float(confirmed_text) and float(hidden) > float(shuffled):
            return "verified"
        return "failed"
    return "present"


def _proof_chips(
    *,
    model_proof: dict[str, Any],
    baseline_proof: dict[str, Any],
    causal_proof: dict[str, Any],
    control_proof: dict[str, Any],
    output_bridge_proof: dict[str, Any],
) -> list[dict[str, str]]:
    statuses = {
        "model_proof": "present" if model_proof.get("status") == "present" else "missing",
        "cas_readout": _readout_chip_status(baseline_proof),
        "causal_proof": _causal_chip_status(causal_proof),
        "control_proof": _control_chip_status(control_proof),
        "output_proof": _output_chip_status(output_bridge_proof),
        "packet_proof": "present",
    }
    details = {
        "model_proof": "Model identity/hash evidence is recorded in the packet.",
        "cas_readout": "Corrected Stage 9 40E hidden-state readout beats text and shuffled controls.",
        "causal_proof": "Subspace ablation/control evidence is recorded for the Stage 9 40E readout.",
        "control_proof": "Candidate cover/control evidence is recorded for the Stage 9 40E run.",
        "output_proof": "Eta-to-epsilon readable bridge output evidence is recorded.",
        "packet_proof": "Evidence Packet schema, trace ID, and source artifact hashes are recorded.",
    }
    return [
        {
            "id": chip_id,
            "name": PROOF_CHIP_NAMES[chip_id],
            "status": statuses[chip_id],
            "detail": details[chip_id],
        }
        for chip_id in REQUIRED_PROOF_CHIPS
    ]


def _proof_chips_pass(proof_chips: list[dict[str, str]]) -> bool:
    by_id = {chip["id"]: chip["status"] for chip in proof_chips}
    if not all(by_id.get(chip_id) in PASSING_PROOF_STATUSES for chip_id in REQUIRED_PROOF_CHIPS):
        return False
    return all(by_id.get(chip_id) == "verified" for chip_id in STRICT_VERIFIED_PROOF_CHIPS)


def _uniqueness_gate_passed(uniqueness_proof: dict[str, Any]) -> bool:
    if uniqueness_proof.get("status") != "present":
        return False
    summary = _mapping_or_empty(uniqueness_proof.get("summary"))
    source = _mapping_or_empty(uniqueness_proof.get("source_fields"))
    status = str(
        source.get("status")
        or summary.get("status")
        or ""
    ).lower()
    condition3 = summary.get("condition3_passed")
    if condition3 is None:
        condition3 = summary.get("condition_3_passed")
    if condition3 is None:
        condition3 = summary.get("matched_taxonomy_gate_passed")
    if condition3 is None:
        condition3 = summary.get("uniqueness_gate_passed")
    control_b = summary.get("control_b_passed")
    control_c = summary.get("control_c_passed")
    if status in PASSING_UNIQUENESS_STATUSES:
        return True
    if condition3 is True:
        return True
    return control_b is True and control_c is True


def _final_verdict(
    *,
    proof_chips: list[dict[str, str]],
    uniqueness_proof: dict[str, Any],
    explicit_decision: dict[str, Any] | None,
) -> str:
    if explicit_decision is None:
        return REVIEW_VERDICT
    if not _proof_chips_pass(proof_chips):
        return REVIEW_VERDICT
    verdict = explicit_decision.get("verdict")
    if verdict == "ACCEPT" and not _uniqueness_gate_passed(uniqueness_proof):
        return REVIEW_VERDICT
    return str(verdict) if verdict in FINAL_VERDICTS else REVIEW_VERDICT


def _verdict_rationale(
    *,
    tier_statuses: dict[str, str],
    proof_chips: list[dict[str, str]],
    uniqueness_proof: dict[str, Any],
    explicit_decision: dict[str, Any] | None,
    final_verdict: str,
) -> str:
    missing = [
        tier
        for tier, status in tier_statuses.items()
        if tier in {"causal", "control", "output_bridge", "verifier"} and status != "present"
    ]
    if missing:
        return (
            "Merged packet is review-only because required proof tiers are missing: "
            + ", ".join(missing)
            + "."
        )
    weak_chips = [
        chip["id"]
        for chip in proof_chips
        if chip["status"] not in PASSING_PROOF_STATUSES
    ]
    if weak_chips:
        return (
            "Verifier decision is not final because required proof chips are not "
            "pass-ready: " + ", ".join(weak_chips) + "."
        )
    if (
        explicit_decision is not None
        and explicit_decision.get("verdict") == "ACCEPT"
        and not _uniqueness_gate_passed(uniqueness_proof)
    ):
        return (
            "Verifier decision is not final because matched-taxonomy/uniqueness "
            "proof has not passed."
        )
    if explicit_decision is None:
        return (
            "All merger-side proof tiers are present, but no valid explicit verifier "
            "decision is attached, so the packet remains human-review only."
        )
    return (
        f"All required proof chips are pass-ready and the attached verifier returned "
        f"`{final_verdict}` with confidence {explicit_decision['confidence']:.6g}."
    )


def build_packet(
    *,
    readout_report: Path,
    ablation_report: Path | None = None,
    cover_report: Path | None = None,
    bridge_report: Path | None = None,
    uniqueness_report: Path | None = None,
    verifier_report: Path | None = None,
    generated_at: datetime | None = None,
    trace_id_override: str | None = None,
    run_id_override: str | None = None,
    parameter_scale_override: str | None = None,
) -> dict[str, Any]:
    readout = _load_json(readout_report)
    generated = generated_at or datetime.now(UTC)
    readout_artifact = _report_artifact(
        readout_report,
        "stage9_40e_readout_report",
        "stage9_40e_original_baseline_readout_report",
    )
    causal_proof, causal_artifact = _make_optional_proof(
        tier_name="subspace_ablation",
        report_path=ablation_report,
        artifact_id="stage9_40e_subspace_ablation_report",
        artifact_type="stage9_40e_subspace_ablation_report",
    )
    control_proof, control_artifact = _make_optional_proof(
        tier_name="cover_discovery",
        report_path=cover_report,
        artifact_id="stage9_40e_cover_discovery_report",
        artifact_type="stage9_40e_cover_discovery_report",
    )
    output_bridge_proof, bridge_artifact = _make_optional_proof(
        tier_name="output_bridge",
        report_path=bridge_report,
        artifact_id="stage9_40e_bridge_report",
        artifact_type="stage9_40e_bridge_report",
    )
    uniqueness_proof, uniqueness_artifact = _make_optional_proof(
        tier_name="matched_taxonomy",
        report_path=uniqueness_report,
        artifact_id="stage9_40e_matched_taxonomy_report",
        artifact_type="stage9_40e_matched_taxonomy_uniqueness_report",
    )
    verifier_proof, verifier_artifact, explicit_decision = _make_verifier_proof(verifier_report)
    model_proof = _extract_model_proof(
        readout, readout_artifact, parameter_scale_override=parameter_scale_override
    )
    readout_proof = _make_readout_proof(readout, readout_artifact)
    baseline_proof = _make_baseline_proof(readout)

    tier_statuses = {
        "model": "present",
        "readout": "present",
        "baseline": "present",
        "causal": causal_proof["status"],
        "control": control_proof["status"],
        "output_bridge": output_bridge_proof["status"],
        "uniqueness": uniqueness_proof["status"],
        "verifier": verifier_proof["status"],
    }
    proof_chips = _proof_chips(
        model_proof=model_proof,
        baseline_proof=baseline_proof,
        causal_proof=causal_proof,
        control_proof=control_proof,
        output_bridge_proof=output_bridge_proof,
    )
    final_verdict = _final_verdict(
        proof_chips=proof_chips,
        uniqueness_proof=uniqueness_proof,
        explicit_decision=explicit_decision,
    )
    input_artifacts = [
        artifact
        for artifact in (
            readout_artifact,
            causal_artifact,
            control_artifact,
            bridge_artifact,
            uniqueness_artifact,
            verifier_artifact,
        )
        if artifact is not None
    ]

    return {
        "schema_version": SCHEMA_VERSION,
        "trace_id": trace_id_override or _extract_trace_id(readout),
        "run_id": run_id_override or _extract_run_id(readout),
        "generated_at": generated.isoformat(),
        "method_label": METHOD_LABEL,
        "model_proof": model_proof,
        "readout_proof": readout_proof,
        "baseline_proof": baseline_proof,
        "causal_proof": causal_proof,
        "control_proof": control_proof,
        "output_bridge_proof": output_bridge_proof,
        "matched_taxonomy_proof": uniqueness_proof,
        "tier_statuses": tier_statuses,
        "verifier": verifier_proof,
        "verification": {
            "proof_chips": proof_chips,
            "explicit_verifier_decision": explicit_decision,
            "proof_chip_gate": "passed" if _proof_chips_pass(proof_chips) else "blocked",
        },
        "verdict": final_verdict,
        "verdict_rationale": _verdict_rationale(
            tier_statuses=tier_statuses,
            proof_chips=proof_chips,
            uniqueness_proof=uniqueness_proof,
            explicit_decision=explicit_decision,
            final_verdict=final_verdict,
        ),
        "caveats": [
            (
                "ACCEPT/SUPPRESS requires pass-ready proof chips and an attached "
                "explicit verifier decision."
            ),
            (
                "Readout-only packets preserve the corrected PR #102 baseline "
                "but remain flagged for human review."
            ),
            (
                "ACCEPT additionally requires matched-taxonomy/uniqueness proof; "
                "matched-ablation controls alone do not close that gate."
            ),
        ],
        "provenance": {
            "input_artifacts": input_artifacts,
            "input_count": len(input_artifacts),
            "readout_report": str(readout_report),
            "ablation_report": str(ablation_report) if ablation_report else None,
            "cover_report": str(cover_report) if cover_report else None,
            "bridge_report": str(bridge_report) if bridge_report else None,
            "uniqueness_report": str(uniqueness_report) if uniqueness_report else None,
            "verifier_report": str(verifier_report) if verifier_report else None,
        },
    }


def render_markdown(packet: dict[str, Any]) -> str:
    baseline = packet["baseline_proof"]
    tiers = packet["tier_statuses"]
    caveats = "\n".join(f"- {caveat}" for caveat in packet["caveats"])
    verification = _mapping_or_empty(packet.get("verification"))
    proof_chips = verification.get("proof_chips")
    if isinstance(proof_chips, list):
        proof_rows = "\n".join(
            f"| {chip.get('name', chip.get('id'))} | {chip.get('status')} | {chip.get('detail')} |"
            for chip in proof_chips
            if isinstance(chip, dict)
        )
    else:
        proof_rows = ""
    explicit = _mapping_or_empty(verification.get("explicit_verifier_decision"))
    if explicit:
        verifier_rows = f"""
## Verifier Decision

| Field | Value |
| --- | --- |
| Verdict | `{explicit.get("verdict")}` |
| Confidence | {float(explicit.get("confidence", 0.0)):.6g} |
| Source | {explicit.get("source")} |
| Scope | {explicit.get("decision_scope")} |
| Reason | {explicit.get("reason")} |
"""
    else:
        verifier_rows = ""
    causal_primary = (
        packet.get("causal_proof", {})
        .get("summary", {})
        .get("primary_result")
    )
    if causal_primary:
        causal_rows = f"""
## Causal Proof

| Metric | Value |
| --- | ---: |
| Original hidden readout | {causal_primary["original_accuracy_pct"]:.6g}% |
| After learned-subspace ablation | {causal_primary["ablated_accuracy_pct"]:.6g}% |
| True disruption | {causal_primary["true_disruption_pp"]:.6g} pp |
| Random same-rank mean disruption | {causal_primary["random_same_rank_mean_disruption_pp"]:.6g} pp |
| Random same-rank max disruption | {causal_primary["random_same_rank_max_disruption_pp"]:.6g} pp |
| Chance baseline | {causal_primary["chance_baseline_accuracy_pct"]:.6g}% |
| Guard status | {causal_primary["guard_status"]} |
"""
    else:
        causal_rows = ""
    control_summary = packet.get("control_proof", {}).get("summary", {})
    if control_summary.get("class_count") is not None:
        control_rows = f"""
## Control / Cover Proof

| Metric | Value |
| --- | ---: |
| Candidate classes | {control_summary["class_count"]} |
| Selected layer | {control_summary.get("selected_layer")} |
| Top-k neurons per class | {control_summary.get("top_k")} |
| Caveat | {control_summary.get("caveat", "candidate cover discovery")} |
"""
    else:
        control_rows = ""
    bridge_summary = packet.get("output_bridge_proof", {}).get("summary", {})
    bridge_key = bridge_summary.get("key_comparisons", {})
    bridge_pred = bridge_summary.get("probe_prediction", {})
    if bridge_key:
        bridge_rows = f"""
## Output Bridge Proof

| Metric | Value |
| --- | ---: |
| Cases | {bridge_summary.get("n_cases")} |
| Selected element accuracy | {float(bridge_pred.get("selected_element_accuracy", 0.0)):.6g} |
| Probe-readable delta vs none | {float(bridge_key.get("probe_readable_delta_vs_none", 0.0)):.6g} |
| Probe-readable minus partner | {float(bridge_key.get("probe_readable_minus_partner_readable_margin", 0.0)):.6g} |
| Gold-readable delta vs none | {float(bridge_key.get("gold_readable_delta_vs_none", 0.0)):.6g} |
| Probe-raw delta vs none | {float(bridge_key.get("probe_raw_delta_vs_none", 0.0)):.6g} |
| Probe-readable gate | {'passed' if bridge_summary.get("probe_readable_gate_passed") else 'failed'} |
"""
    else:
        bridge_rows = ""
    return f"""# Stage 9 40E Evidence Packet

- Schema version: `{packet["schema_version"]}`
- Trace ID: `{packet["trace_id"]}`
- Run ID: `{packet["run_id"]}`
- Method: `{packet["method_label"]}`
- Verdict: `{packet["verdict"]}`

## Tier Status

| Tier | Status |
| --- | --- |
| Model proof | {tiers["model"]} |
| Readout proof | {tiers["readout"]} |
| Baseline proof | {tiers["baseline"]} |
| Causal proof | {tiers["causal"]} |
| Control proof | {tiers["control"]} |
| Output/bridge proof | {tiers["output_bridge"]} |
| Matched-taxonomy proof | {tiers["uniqueness"]} |
| Verifier | {tiers["verifier"]} |

## Proof Chips

| Proof | Status | Detail |
| --- | --- | --- |
{proof_rows}

## Baseline Proof

| Metric | Corrected value |
| --- | ---: |
| Hidden readout | {baseline["hidden_probe_test_acc_pct"]:.6g}% |
| Confirmed text | {baseline["confirmed_text_test_acc_pct"]:.6f}% |
| Text-hash baseline | {baseline["text_hash_test_acc_pct"]:.6g}% |
| Shuffled-label mean | {baseline["shuffled_label_hidden_mean_test_acc_pct"]:.6g}% |
| compact-gloss v0 | blocked at {baseline["compact_gloss_v0_text_only_acc_pct"]:.6g}% text-only |

{causal_rows}{control_rows}{bridge_rows}{verifier_rows}
## Rationale

{packet["verdict_rationale"]}

## Caveats

{caveats}
"""


def write_packet(packet: dict[str, Any], output_json: Path, output_markdown: Path) -> None:
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_markdown.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(
        json.dumps(packet, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    output_markdown.write_text(render_markdown(packet), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--readout-report", type=Path, default=DEFAULT_READOUT_REPORT)
    parser.add_argument("--ablation-report", type=Path)
    parser.add_argument("--cover-report", type=Path)
    parser.add_argument("--bridge-report", type=Path)
    parser.add_argument("--uniqueness-report", type=Path)
    parser.add_argument("--verifier-report", type=Path)
    parser.add_argument("--output-json", type=Path, default=DEFAULT_OUTPUT_JSON)
    parser.add_argument("--output-markdown", type=Path, default=DEFAULT_OUTPUT_MARKDOWN)
    parser.add_argument(
        "--trace-id",
        default=None,
        help=(
            "Override the packet trace_id. Defaults to the readout report's trace_id, "
            "else the bundled Stage 9 40E static identity. Set this when the source "
            "reports come from a different substrate (e.g. a Pythia-160M reproduction) "
            "so the packet self-labels its true provenance instead of inheriting the "
            "20B scaffold identity."
        ),
    )
    parser.add_argument(
        "--run-id",
        default=None,
        help="Override the packet run_id (see --trace-id for when to use this).",
    )
    parser.add_argument(
        "--parameter-scale",
        default=None,
        help=(
            "Override the model parameter_scale label (e.g. '160M'). Defaults to the "
            "readout report's value, else '20B'. Set this so a non-20B reproduction "
            "packet does not inherit the 20B scale label."
        ),
    )
    args = parser.parse_args()

    packet = build_packet(
        readout_report=args.readout_report,
        ablation_report=args.ablation_report,
        cover_report=args.cover_report,
        bridge_report=args.bridge_report,
        uniqueness_report=args.uniqueness_report,
        verifier_report=args.verifier_report,
        trace_id_override=args.trace_id,
        run_id_override=args.run_id,
        parameter_scale_override=args.parameter_scale,
    )
    write_packet(packet, args.output_json, args.output_markdown)
    print(f"wrote JSON packet: {args.output_json}")
    print(f"wrote markdown packet: {args.output_markdown}")
    print(f"verdict: {packet['verdict']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
