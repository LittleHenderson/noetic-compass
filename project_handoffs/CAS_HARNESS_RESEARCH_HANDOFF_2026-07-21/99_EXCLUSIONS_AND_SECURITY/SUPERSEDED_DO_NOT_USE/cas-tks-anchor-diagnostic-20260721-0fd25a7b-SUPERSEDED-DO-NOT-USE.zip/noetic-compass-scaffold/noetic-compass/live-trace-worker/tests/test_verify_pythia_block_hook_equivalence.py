from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest
import torch
from torch import nn

from scripts.verify_pythia_block_hook_equivalence import (
    HookEquivalenceError,
    LICENSING_STATUS,
    assert_equivalence_contract,
    atomic_write_json,
    build_equivalence_checks,
    capture_and_verify_hook_semantics,
    locate_pythia_gpt_neox_adapter,
    validate_exact_revision,
    validate_pythia_model_id,
    validate_resolved_commits,
)


class AddBlock(nn.Module):
    def __init__(self, amount: float) -> None:
        super().__init__()
        self.amount = nn.Parameter(torch.tensor(amount), requires_grad=False)

    def forward(self, hidden_states: torch.Tensor, **_kwargs) -> torch.Tensor:
        return hidden_states + self.amount


class ScaleFinalNorm(nn.Module):
    def __init__(self, scale: float = 0.25) -> None:
        super().__init__()
        self.scale = nn.Parameter(torch.tensor(scale), requires_grad=False)

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        return hidden_states * self.scale


class FakeGPTNeoXBackbone(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.layers = nn.ModuleList([AddBlock(1.0), AddBlock(2.0), AddBlock(3.0)])
        self.final_layer_norm = ScaleFinalNorm()


class FakePythiaForCausalLM(nn.Module):
    """Mimic GPT-NeoX hidden-state collection around the final norm."""

    def __init__(self) -> None:
        super().__init__()
        self.gpt_neox = FakeGPTNeoXBackbone()

    def forward(
        self,
        input_ids: torch.Tensor,
        *,
        output_hidden_states: bool,
        use_cache: bool,
        return_dict: bool,
        **_kwargs,
    ) -> SimpleNamespace:
        assert output_hidden_states is True
        assert use_cache is False
        assert return_dict is True
        hidden = input_ids.to(torch.float32).unsqueeze(-1).repeat(1, 1, 4)
        all_hidden = []
        for layer in self.gpt_neox.layers:
            all_hidden.append(hidden)
            hidden = layer(hidden)
        hidden = self.gpt_neox.final_layer_norm(hidden)
        all_hidden.append(hidden)
        return SimpleNamespace(hidden_states=tuple(all_hidden))


def test_fake_modules_prove_nonfinal_and_final_norm_boundaries() -> None:
    model = FakePythiaForCausalLM().eval()

    result = capture_and_verify_hook_semantics(
        model=model,
        model_inputs={"input_ids": torch.tensor([[1, 2, 3]], dtype=torch.long)},
        atol=0.0,
        rtol=0.0,
    )

    assert result["all_required_checks_pass"] is True
    assert result["block_count"] == 3
    assert result["hidden_state_count"] == 4
    assert [item["path"] for item in result["block_modules"]] == [
        "gpt_neox.layers.0",
        "gpt_neox.layers.1",
        "gpt_neox.layers.2",
    ]
    assert all(item["hook_fire_count"] == 1 for item in result["block_modules"])
    assert all(
        item["exact_equal"] for item in result["non_final_block_to_hidden_state"]
    )
    assert result["final_block_to_pre_final_norm"]["exact_equal"] is True
    assert (
        result["post_final_norm_hidden_state_to_norm_output"]["exact_equal"] is True
    )
    informational = result["final_block_to_post_norm_hidden_state_informational"]
    assert informational["required_gate"] is False
    assert informational["used_as_final_block_equivalence"] is False
    assert informational["allclose"] is False


def test_tampered_nonfinal_hidden_state_fails_closed() -> None:
    blocks = {
        0: torch.ones(1, 2, 3),
        1: torch.full((1, 2, 3), 2.0),
    }
    hidden_states = (
        torch.zeros(1, 2, 3),
        torch.full((1, 2, 3), 9.0),
        torch.full((1, 2, 3), 0.5),
    )
    checks = build_equivalence_checks(
        block_tensors=blocks,
        hidden_states=hidden_states,
        final_norm_pre_input=blocks[1].clone(),
        final_norm_output=hidden_states[-1].clone(),
        atol=0.0,
        rtol=0.0,
    )

    assert checks["all_required_checks_pass"] is False
    with pytest.raises(HookEquivalenceError, match=r"block\[0\].*hidden_states\[1\]"):
        assert_equivalence_contract(checks)


def test_tampered_final_pre_norm_input_fails_closed() -> None:
    blocks = {0: torch.ones(1, 2, 3)}
    hidden_states = (torch.zeros(1, 2, 3), torch.full((1, 2, 3), 0.5))
    checks = build_equivalence_checks(
        block_tensors=blocks,
        hidden_states=hidden_states,
        final_norm_pre_input=torch.full((1, 2, 3), 7.0),
        final_norm_output=hidden_states[-1].clone(),
        atol=0.0,
        rtol=0.0,
    )

    assert checks["all_required_checks_pass"] is False
    with pytest.raises(HookEquivalenceError, match="final block output"):
        assert_equivalence_contract(checks)


def test_adapter_locator_rejects_alias_or_missing_exact_paths() -> None:
    good = FakePythiaForCausalLM()
    adapter = locate_pythia_gpt_neox_adapter(good)
    assert adapter.final_layer_norm_path == "gpt_neox.final_layer_norm"

    bad = nn.Module()
    bad.backbone = FakeGPTNeoXBackbone()
    with pytest.raises(RuntimeError, match="model.gpt_neox"):
        locate_pythia_gpt_neox_adapter(bad)


def test_exact_model_id_and_revision_are_required() -> None:
    assert validate_pythia_model_id("EleutherAI/pythia-160m") == (
        "EleutherAI/pythia-160m"
    )
    with pytest.raises(ValueError, match="Pythia/GPT-NeoX"):
        validate_pythia_model_id("Qwen/Qwen2.5-0.5B")

    revision = "a" * 40
    assert validate_exact_revision(revision.upper()) == revision
    validate_resolved_commits(revision, {revision})
    with pytest.raises(RuntimeError, match="do not exactly equal"):
        validate_resolved_commits(revision, {"b" * 40})
    with pytest.raises(ValueError, match="40-hex"):
        validate_exact_revision("main")


def test_atomic_json_report_round_trips_and_stays_nonlicensed(tmp_path: Path) -> None:
    path = tmp_path / "preflight.json"
    payload = {
        "status": "PREFLIGHT_PASS",
        "licensing_status": LICENSING_STATUS,
        "claim_eligible": False,
    }

    verification = atomic_write_json(path, payload)

    assert path.read_text(encoding="utf-8").endswith("\n")
    assert verification["reopen_parse_verified"] is True
    assert verification["temporary_path_absent"] is True
    assert verification["bytes"] == path.stat().st_size
    assert not list(tmp_path.glob("*.tmp"))
