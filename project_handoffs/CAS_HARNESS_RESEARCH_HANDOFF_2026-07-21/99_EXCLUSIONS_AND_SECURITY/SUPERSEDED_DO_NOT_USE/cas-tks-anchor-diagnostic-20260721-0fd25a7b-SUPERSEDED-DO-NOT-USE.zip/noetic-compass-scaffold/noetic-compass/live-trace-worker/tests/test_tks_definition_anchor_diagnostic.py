from __future__ import annotations

from dataclasses import replace
import hashlib
import json
from pathlib import Path

import numpy as np
import pytest

from scripts.run_tks_definition_anchor_diagnostic import (
    COMPACT_ARM_NAME,
    DEFAULT_COMPACT_SOURCE,
    DEFAULT_SENSITIVITY_PATH,
    DEFAULT_STAGE7_PATH,
    DIAGNOSTIC_CLASS,
    FOUNDATION_LABELS,
    NON_CLAIM,
    OPERATIONAL_ARM_NAME,
    ORIGINAL_ARM_NAME,
    PREREGISTERED_CHANGED_FOUNDATIONS,
    SENSITIVITY_SPLIT,
    DefinitionArm,
    EvalScenario,
    apply_permanent_diagnostic_status,
    build_compact_arm,
    build_compact_definition_records,
    build_tks_source_arm,
    char_ngram_tfidf_anchor_predictions,
    classification_metrics,
    cluster_bootstrap_classification,
    enforce_token_limit,
    evaluate_evidence,
    legacy_code_to_foundation,
    load_evaluation_scenarios,
    load_tks_f28_definitions,
    mcnemar_exact,
    save_raw_diagnostic_artifact,
    select_shared_primary_layer,
    sha256_definition_records,
    stable_seed,
    tfidf_anchor_predictions,
    validate_model_revision,
    validate_resolved_model_revision,
    validate_layer_range,
)


def _owner_payload() -> dict:
    items = []
    for drive in range(1, 8):
        for world in "abcd":
            items.append(
                {
                    "code": f"{drive}{world}",
                    "title": f"Title {drive}{world}",
                    "definition": f"Definition for {drive}{world}",
                }
            )
    return {
        "schema_version": "tks_owner_provided_axis_definitions.v1",
        "tks_28_foundations": items,
    }


def _synthetic_arms() -> list[DefinitionArm]:
    definitions = build_compact_definition_records()

    def arm(
        name: str,
        role: str,
        selection: bool,
        records=definitions,
    ) -> DefinitionArm:
        return DefinitionArm(
            name=name,
            source_role=role,
            source_kind="synthetic_test",
            source_path="synthetic",
            source_sha256="0" * 64,
            derived_payload_sha256=sha256_definition_records(records),
            include_in_shared_layer_selection=selection,
            admitted=True,
            definitions=records,
        )

    operational_definitions = tuple(
        replace(
            record,
            definition=f"{record.definition} Operational rewrite.",
            prototype_text=f"{record.title}\n{record.definition} Operational rewrite.",
        )
        if record.label in PREREGISTERED_CHANGED_FOUNDATIONS
        else record
        for record in definitions
    )
    return [
        arm(ORIGINAL_ARM_NAME, "owner_original_raw", True),
        arm(
            OPERATIONAL_ARM_NAME,
            "deployed_operational_rewrite",
            True,
            operational_definitions,
        ),
        arm(COMPACT_ARM_NAME, "diagnostic_compact_comparator", False),
    ]


def _synthetic_scenarios() -> list[EvalScenario]:
    scenarios = []
    for split in ("stage7_val", "stage7_test", SENSITIVITY_SPLIT):
        for index, label in enumerate(FOUNDATION_LABELS):
            drive, register = label.split("|")
            scenarios.append(
                EvalScenario(
                    scenario_id=f"{split}-{index}",
                    prompt=f"Prompt {split} {label}",
                    foundation=label,
                    drive=drive,
                    register=register,
                    split=split,
                    bank="synthetic",
                    group_id=f"{split}-group-{index // 2}",
                    group_id_source="synthetic_pair",
                )
            )
    return scenarios


def _synthetic_evidence() -> tuple[
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    np.ndarray,
    list[EvalScenario],
    list[DefinitionArm],
]:
    scenarios = _synthetic_scenarios()
    arms = _synthetic_arms()
    label_index = {label: index for index, label in enumerate(FOUNDATION_LABELS)}
    identity = np.eye(len(FOUNDATION_LABELS), dtype=np.float32)
    evaluation = np.stack(
        [
            np.stack([identity[label_index[item.foundation]], identity[label_index[item.foundation]]])
            for item in scenarios
        ]
    )
    definitions = np.zeros((3, 28, 2, 28), dtype=np.float32)
    # At layer 3, D3 is wrong and A124 is right. At layer 7 both are right,
    # so the shared Stage7-validation rule must freeze layer 7.
    definitions[0, :, 0, :] = np.roll(identity, 1, axis=0)
    definitions[1, :, 0, :] = identity
    definitions[2, :, 0, :] = identity
    definitions[:, :, 1, :] = identity
    return (
        np.asarray([3, 7], dtype=np.int16),
        evaluation,
        evaluation.copy(),
        definitions,
        definitions.copy(),
        scenarios,
        arms,
    )


def test_owner_loader_maps_1a_through_7d_and_binds_raw_hash(tmp_path: Path):
    path = tmp_path / "owner.json"
    raw = json.dumps(_owner_payload(), indent=2).encode("utf-8")
    path.write_bytes(raw)

    definitions = load_tks_f28_definitions(path)

    assert len(definitions) == 28
    assert definitions[0].label == "F1|T"
    assert definitions[1].label == "F1|A"
    assert definitions[2].label == "F1|f"
    assert definitions[3].label == "F1|E"
    assert definitions[-1].label == "F7|E"
    assert hashlib.sha256(raw).hexdigest() == hashlib.sha256(path.read_bytes()).hexdigest()
    assert legacy_code_to_foundation("7d") == "F7|E"


def test_owner_loader_rejects_missing_or_duplicate_foundation(tmp_path: Path):
    payload = _owner_payload()
    payload["tks_28_foundations"].pop()
    path = tmp_path / "bad.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(ValueError, match="mismatch"):
        load_tks_f28_definitions(path)


def test_source_arm_fails_closed_on_hash_mismatch(tmp_path: Path):
    path = tmp_path / "owner.json"
    path.write_text(json.dumps(_owner_payload()), encoding="utf-8")

    with pytest.raises(ValueError, match="hash mismatch"):
        build_tks_source_arm(
            path=path,
            expected_sha256="0" * 64,
            requested_name="test_canary",
            allow_unadmitted_canary=True,
        )


def test_compact_arm_is_honestly_named_compositional_and_source_bound():
    arm = build_compact_arm(
        path=DEFAULT_COMPACT_SOURCE,
        expected_sha256=hashlib.sha256(DEFAULT_COMPACT_SOURCE.read_bytes()).hexdigest(),
        allow_unadmitted_canary=False,
    )

    assert arm.name == COMPACT_ARM_NAME
    assert arm.source_role == "diagnostic_compact_comparator"
    assert not arm.include_in_shared_layer_selection
    assert len(arm.definitions) == 28
    assert "Drive concern:" in arm.definitions[0].definition
    assert "Register cue:" in arm.definitions[0].definition


def test_fixed_scenario_loaders_use_val_test_and_grouped_sensitivity_variants():
    scenarios, provenance = load_evaluation_scenarios(
        DEFAULT_STAGE7_PATH,
        DEFAULT_SENSITIVITY_PATH,
        allow_unpinned_canary=False,
    )
    counts = {
        split: sum(item.split == split for item in scenarios)
        for split in {item.split for item in scenarios}
    }

    assert counts == {
        "stage7_val": 672,
        "stage7_test": 2352,
        SENSITIVITY_SPLIT: 56,
    }
    assert all(item.split != "train" for item in scenarios)
    assert provenance["banks_pinned"] is True
    assert "not independently authored neutral holdouts" in provenance["source_generator_bias"]
    summary = provenance["group_integrity"]
    assert summary["stage7_val"]["group_count"] == 336
    assert summary["stage7_test"]["group_count"] == 1176
    assert summary[SENSITIVITY_SPLIT]["group_count"] == 28
    assert summary["stage7_val_test_group_overlap_count"] == 0
    sensitivity = [item for item in scenarios if item.split == SENSITIVITY_SPLIT]
    by_group = {}
    for item in sensitivity:
        by_group.setdefault(item.group_id, []).append(item)
    assert set(map(len, by_group.values())) == {2}
    assert all(len({item.foundation for item in rows}) == 1 for rows in by_group.values())


def test_model_revision_requires_pin_and_transformers_resolution():
    with pytest.raises(ValueError, match="40-hex"):
        validate_model_revision("main", False)
    assert validate_model_revision("a" * 40, False)["integrity_pinned"] is True

    with pytest.raises(RuntimeError, match="did not report"):
        validate_resolved_model_revision("a" * 40, set(), {"snapshot_commits": []})
    with pytest.raises(RuntimeError, match="absent"):
        validate_resolved_model_revision("a" * 40, {"b" * 40}, {"snapshot_commits": []})
    validate_resolved_model_revision(
        "a" * 40,
        {"a" * 40},
        {"snapshot_commits": ["a" * 40]},
    )


def test_truncation_fails_closed():
    enforce_token_limit(512, 512)
    with pytest.raises(RuntimeError, match="fails closed"):
        enforce_token_limit(513, 512)


def test_layer_range_validation_fails_closed():
    validate_layer_range(layer_start=0, layer_end=11, total_layers=12)
    with pytest.raises(ValueError, match="negative"):
        validate_layer_range(layer_start=-1, layer_end=2, total_layers=12)
    with pytest.raises(ValueError, match="Reversed"):
        validate_layer_range(layer_start=5, layer_end=4, total_layers=12)
    with pytest.raises(ValueError, match="outside"):
        validate_layer_range(layer_start=0, layer_end=12, total_layers=12)


def test_shared_layer_selection_uses_validation_mean_only():
    per_layer = [
        {
            "layer": 3,
            "poolings": {
                "mean": {
                    "arms": {
                        ORIGINAL_ARM_NAME: {
                            "splits": {
                                "stage7_val": {"full": {"accuracy": 0.8, "macro_f1": 0.8}},
                                "stage7_test": {"full": {"accuracy": 0.0, "macro_f1": 0.0}},
                            }
                        },
                        OPERATIONAL_ARM_NAME: {
                            "splits": {
                                "stage7_val": {"full": {"accuracy": 0.8, "macro_f1": 0.8}},
                                "stage7_test": {"full": {"accuracy": 0.0, "macro_f1": 0.0}},
                            }
                        },
                    }
                }
            },
        },
        {
            "layer": 7,
            "poolings": {
                "mean": {
                    "arms": {
                        ORIGINAL_ARM_NAME: {
                            "splits": {
                                "stage7_val": {"full": {"accuracy": 0.7, "macro_f1": 0.7}},
                                "stage7_test": {"full": {"accuracy": 1.0, "macro_f1": 1.0}},
                            }
                        },
                        OPERATIONAL_ARM_NAME: {
                            "splits": {
                                "stage7_val": {"full": {"accuracy": 0.7, "macro_f1": 0.7}},
                                "stage7_test": {"full": {"accuracy": 1.0, "macro_f1": 1.0}},
                            }
                        },
                    }
                }
            },
        },
    ]

    selected, _trace = select_shared_primary_layer(
        per_layer,
        selection_arm_names=[ORIGINAL_ARM_NAME, OPERATIONAL_ARM_NAME],
    )

    assert selected == 0


def test_synthetic_evaluation_selects_shared_layer_and_reports_all_axes():
    layers, mean, last, definitions_mean, definitions_last, scenarios, arms = (
        _synthetic_evidence()
    )

    report = evaluate_evidence(
        layers=layers,
        eval_mean=mean,
        eval_last=last,
        definition_mean=definitions_mean,
        definition_last=definitions_last,
        scenarios=scenarios,
        arms=arms,
        seed=17,
        bootstrap_replicates=20,
    )

    assert report["shared_validation_selected_primary_layer"] == 7
    selected = report["selected_layer_results"]["mean"]["arms"][ORIGINAL_ARM_NAME]
    assert selected["splits"]["stage7_test"]["full"]["accuracy"] == 1.0
    assert selected["splits"]["stage7_test"]["drive"]["macro_f1"] == 1.0
    assert selected["splits"]["stage7_test"]["register"]["accuracy"] == 1.0
    assert report["deterministic_shuffled_label_control"]["is_derangement"] is True
    assert "primary_d3_vs_a124" in report["paired_comparisons"]
    assert report["sole_preregistered_primary_estimand"]["name"] == (
        "D3_MINUS_A124_FULL28_ACCURACY_DELTA"
    )
    subsets = report["paired_comparisons"]["primary_d3_vs_a124"][
        "prespecified_changed_8_and_unchanged_20"
    ]["subsets"]
    assert len(subsets["changed_8_prespecified_sensitivity"]["labels"]) == 8
    assert len(subsets["unchanged_20_negative_control"]["labels"]) == 20
    assert "diagnostic_d3_vs_compact" not in report["paired_comparisons"]


def test_grouped_bootstrap_is_deterministic_and_reports_group_count():
    y_true = np.asarray(["a", "a", "b", "b"])
    y_pred = np.asarray(["a", "b", "b", "b"])
    groups = np.asarray(["g1", "g1", "g2", "g2"])
    first = cluster_bootstrap_classification(
        y_true,
        y_pred,
        groups,
        labels=("a", "b"),
        replicates=50,
        seed=stable_seed(7, "test"),
    )
    second = cluster_bootstrap_classification(
        y_true,
        y_pred,
        groups,
        labels=("a", "b"),
        replicates=50,
        seed=stable_seed(7, "test"),
    )

    assert first == second
    assert first["bootstrap_group_count"] == 2
    assert classification_metrics(y_true, y_pred, ("a", "b"))["accuracy"] == 0.75


def test_tfidf_and_mcnemar_controls_are_operational():
    predicted, diagnostics = tfidf_anchor_predictions(
        ["apple orchard", "ocean wave"],
        ["apple fruit", "ocean water"],
        ["A", "B"],
    )
    assert predicted.tolist() == ["A", "B"]
    assert diagnostics["zero_evaluation_vectors"] == 0
    char_predicted, char_diagnostics = char_ngram_tfidf_anchor_predictions(
        ["apple orchard", "ocean wave"],
        ["apple fruit", "ocean water"],
        ["A", "B"],
        minimum_n=3,
        maximum_n=5,
    )
    assert char_predicted.tolist() == ["A", "B"]
    assert char_diagnostics["feature_family"] == "character_3_to_5_grams"

    stats = mcnemar_exact(
        np.asarray(["A", "B", "A"]),
        np.asarray(["A", "B", "B"]),
        np.asarray(["B", "B", "A"]),
    )
    assert stats["left_correct_right_wrong"] == 1
    assert stats["left_wrong_right_correct"] == 1
    assert stats["two_sided_exact_p_value"] == 1.0


def test_raw_npz_contains_replay_fields_without_pickle(tmp_path: Path):
    layers, mean, last, definitions_mean, definitions_last, scenarios, arms = (
        _synthetic_evidence()
    )
    path = tmp_path / "raw.npz"
    verification = save_raw_diagnostic_artifact(
        path,
        provenance={"diagnostic_class": DIAGNOSTIC_CLASS},
        scenarios=scenarios,
        arms=arms,
        layers=layers,
        eval_mean=mean,
        eval_last=last,
        eval_token_counts=np.full(len(scenarios), 5, dtype=np.int32),
        eval_token_id_sha256=np.asarray(["a" * 64] * len(scenarios)),
        definition_mean=definitions_mean,
        definition_last=definitions_last,
        definition_token_counts=np.full((3, 28), 7, dtype=np.int32),
        definition_token_id_sha256=np.full((3, 28), "b" * 64),
    )
    assert verification["status"] == (
        "LOCAL_DIAGNOSTIC_ARTIFACT_ATOMIC_WRITE_REOPEN_VERIFIED"
    )
    assert verification["sha256"] == hashlib.sha256(path.read_bytes()).hexdigest()

    with np.load(path, allow_pickle=False) as payload:
        required = {
            "provenance_json",
            "layers",
            "eval_mean",
            "eval_last",
            "eval_token_id_sha256",
            "scenario_ids",
            "scenario_prompts",
            "scenario_splits",
            "scenario_group_ids",
            "arm_names",
            "arm_source_sha256",
            "definition_labels",
            "definition_texts",
            "definition_mean",
            "definition_last",
            "definition_token_id_sha256",
        }
        assert required <= set(payload.files)
        assert payload["eval_mean"].shape == mean.shape
        assert payload["definition_mean"].shape == definitions_mean.shape
        assert payload["scenario_prompts"].dtype.kind == "U"


def test_status_is_permanently_nonlicensed():
    report = {"claim_eligible": True, "licensing_status": "LICENSED"}
    apply_permanent_diagnostic_status(report)

    assert report["diagnostic_class"] == DIAGNOSTIC_CLASS
    assert report["licensing_status"] == "NOT_LICENSED_DIAGNOSTIC_ONLY"
    assert report["claim_eligible"] is False
    assert report["non_claim"] == NON_CLAIM
