"""Verify exact Pythia/GPT-NeoX complete-block hook semantics.

This preflight qualifies one narrow architecture adapter on one exact model
revision.  It verifies that complete GPT-NeoX block forward hooks expose the
same residual-stream tensors represented by ``output_hidden_states`` at the
architecture-appropriate boundaries:

* block ``i`` matches ``hidden_states[i + 1]`` for every non-final block; and
* the final block matches the input to ``gpt_neox.final_layer_norm``.

The final block is deliberately *not* equated with ``hidden_states[-1]`` because
that value is post-final-normalization in GPT-NeoX.  Passing this check does not
validate a semantic probe, another architecture, universality, 300B execution,
or any customer verdict.
"""

from __future__ import annotations

from argparse import ArgumentParser
from dataclasses import dataclass
from datetime import UTC, datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
from typing import Any, Mapping, Sequence
import uuid


SCRIPT_PATH = Path(__file__).resolve()
REPORT_SCHEMA = "cas_harness.pythia_gpt_neox_block_hook_equivalence_preflight.v1"
DIAGNOSTIC_CLASS = "PYTHIA_GPT_NEOX_BLOCK_HOOK_EQUIVALENCE_PREFLIGHT"
LICENSING_STATUS = "NOT_LICENSED_PREFLIGHT_ONLY"
PASS_STATUS = "PREFLIGHT_PASS"
FAIL_STATUS = "PREFLIGHT_FAIL"
ERROR_STATUS = "PREFLIGHT_ERROR"

DEFAULT_PROMPT = (
    "A careful instrument records internal states before and after each processing stage."
)

NON_CLAIM = (
    "This report qualifies only the complete-transformer-block hook boundary for the exact "
    "EleutherAI Pythia model ID and 40-hex revision recorded here. It does not license semantic "
    "probe validity, prompt-injection detection, causal or output control, architecture-general "
    "or universal probing, 300B execution, production readiness, an ACCEPT verdict, or any "
    "customer/investor claim."
)


class HookEquivalenceError(RuntimeError):
    """Raised when the adapter's tensor-boundary equivalence contract fails."""


@dataclass(frozen=True)
class PythiaGPTNeoXAdapter:
    """Exact module boundary used by the Pythia/GPT-NeoX adapter."""

    blocks: tuple[Any, ...]
    final_layer_norm: Any
    block_paths: tuple[str, ...]
    final_layer_norm_path: str


def parse_args(argv: Sequence[str] | None = None) -> Any:
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--model-id", required=True)
    parser.add_argument("--model-revision", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--prompt", default=DEFAULT_PROMPT)
    parser.add_argument("--max-tokens", type=int, default=256)
    parser.add_argument(
        "--device",
        choices=("auto", "cpu", "cuda"),
        default="auto",
        help="auto selects one CUDA device when available, otherwise CPU",
    )
    parser.add_argument(
        "--torch-dtype",
        choices=("auto", "float32", "float16", "bfloat16"),
        default="auto",
    )
    parser.add_argument("--local-files-only", action="store_true")
    parser.add_argument("--atol", type=float, default=1e-6)
    parser.add_argument("--rtol", type=float, default=1e-5)
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    report: dict[str, Any] = base_report(args)
    exit_code = 2
    try:
        model_id = validate_pythia_model_id(args.model_id)
        revision = validate_exact_revision(args.model_revision)
        validate_numeric_options(
            max_tokens=args.max_tokens,
            atol=args.atol,
            rtol=args.rtol,
        )
        if not str(args.prompt).strip():
            raise ValueError("--prompt must contain non-whitespace text")

        model, tokenizer, load_provenance = load_exact_pythia_model(
            model_id=model_id,
            revision=revision,
            device=args.device,
            torch_dtype=args.torch_dtype,
            local_files_only=args.local_files_only,
        )
        tokenized, input_provenance = prepare_model_inputs(
            tokenizer=tokenizer,
            prompt=args.prompt,
            model=model,
            max_tokens=args.max_tokens,
        )
        equivalence = capture_and_verify_hook_semantics(
            model=model,
            model_inputs=tokenized,
            atol=args.atol,
            rtol=args.rtol,
        )
        report.update(
            {
                "status": PASS_STATUS if equivalence["all_required_checks_pass"] else FAIL_STATUS,
                "adapter_qualification_status": (
                    "PYTHIA_GPT_NEOX_BLOCK_HOOK_EQUIVALENCE_VERIFIED"
                    if equivalence["all_required_checks_pass"]
                    else "PYTHIA_GPT_NEOX_BLOCK_HOOK_EQUIVALENCE_FAILED"
                ),
                "model": load_provenance,
                "input": input_provenance,
                "equivalence": equivalence,
            }
        )
        assert_equivalence_contract(equivalence)
        exit_code = 0
    except HookEquivalenceError as exc:
        report["status"] = FAIL_STATUS
        report["adapter_qualification_status"] = (
            "PYTHIA_GPT_NEOX_BLOCK_HOOK_EQUIVALENCE_FAILED"
        )
        report["failure"] = {"type": type(exc).__name__, "message": str(exc)}
    except Exception as exc:  # Persist a fail-closed, non-licensed diagnostic receipt.
        report["status"] = ERROR_STATUS
        report["adapter_qualification_status"] = (
            "PYTHIA_GPT_NEOX_BLOCK_HOOK_EQUIVALENCE_NOT_ESTABLISHED"
        )
        report["failure"] = {"type": type(exc).__name__, "message": str(exc)}

    write_verification = atomic_write_json(args.output, report)
    print(f"[pythia-hook-preflight] report: {args.output.resolve()}")
    print(f"[pythia-hook-preflight] sha256: {write_verification['sha256']}")
    print(f"[pythia-hook-preflight] status: {report['status']}")
    print(f"[pythia-hook-preflight] licensing: {LICENSING_STATUS}")
    return exit_code


def base_report(args: Any) -> dict[str, Any]:
    return {
        "schema_version": REPORT_SCHEMA,
        "diagnostic_class": DIAGNOSTIC_CLASS,
        "created_at": datetime.now(UTC).isoformat(),
        "status": ERROR_STATUS,
        "adapter_qualification_status": (
            "PYTHIA_GPT_NEOX_BLOCK_HOOK_EQUIVALENCE_NOT_ESTABLISHED"
        ),
        "licensing_status": LICENSING_STATUS,
        "claim_eligible": False,
        "universality_status": "NOT_EVALUATED",
        "scope": {
            "adapter": "EleutherAI_Pythia_GPT_NeoX_complete_block.v1",
            "requested_model_id": str(args.model_id),
            "requested_model_revision": str(args.model_revision),
            "requested_revision_contract": "exact_40_hex_commit",
            "explicitly_not_tested": [
                "other_model_revisions",
                "other_GPT_NeoX_model_ids",
                "other_architecture_families",
                "semantic_probe_accuracy",
                "causal_control",
                "prompt_injection_detection",
                "300B_execution",
            ],
        },
        "comparison_contract": {
            "non_final_block_mapping": "block[i] == hidden_states[i+1] for i=0..n-2",
            "final_block_mapping": (
                "block[n-1] == pre_hook_input(gpt_neox.final_layer_norm)"
            ),
            "post_norm_mapping": (
                "hidden_states[-1] == output(gpt_neox.final_layer_norm)"
            ),
            "forbidden_final_mapping": (
                "block[n-1] must not be treated as hidden_states[-1]; that is post-norm"
            ),
            "atol": float(args.atol),
            "rtol": float(args.rtol),
        },
        "runtime": capture_runtime_provenance(),
        "code": capture_code_provenance(),
        "output_contract": {
            "format": "JSON",
            "atomic_write": "same-directory temporary file + flush + fsync + os.replace",
            "reopen_and_parse_verification": True,
            "allow_nan": False,
        },
        "non_claim": NON_CLAIM,
    }


def validate_pythia_model_id(model_id: str) -> str:
    value = str(model_id or "").strip()
    if not re.fullmatch(r"EleutherAI/pythia-[A-Za-z0-9._-]+", value, flags=re.IGNORECASE):
        raise ValueError(
            "--model-id must be an EleutherAI/pythia-* repository ID; this verifier is an "
            "exact Pythia/GPT-NeoX adapter check, not a generic-model verifier"
        )
    return value


def validate_exact_revision(revision: str) -> str:
    value = str(revision or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{40}", value):
        raise ValueError("--model-revision must be an exact 40-hex commit")
    return value


def validate_numeric_options(*, max_tokens: int, atol: float, rtol: float) -> None:
    if max_tokens < 1:
        raise ValueError("--max-tokens must be >= 1")
    if not (0.0 <= float(atol) < float("inf")):
        raise ValueError("--atol must be finite and non-negative")
    if not (0.0 <= float(rtol) < float("inf")):
        raise ValueError("--rtol must be finite and non-negative")


def load_exact_pythia_model(
    *,
    model_id: str,
    revision: str,
    device: str,
    torch_dtype: str,
    local_files_only: bool,
) -> tuple[Any, Any, dict[str, Any]]:
    import torch
    from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer

    selected_device = resolve_device(torch, device)
    selected_dtype = resolve_dtype(torch, torch_dtype)
    common = {
        "revision": revision,
        "local_files_only": bool(local_files_only),
        "trust_remote_code": False,
    }
    config = AutoConfig.from_pretrained(model_id, **common)
    validate_gpt_neox_config(config)
    tokenizer = AutoTokenizer.from_pretrained(model_id, **common)
    model_kwargs: dict[str, Any] = dict(common)
    model_kwargs["config"] = config
    if selected_dtype is not None:
        model_kwargs["torch_dtype"] = selected_dtype
    model = AutoModelForCausalLM.from_pretrained(model_id, **model_kwargs)
    model.eval()
    model.to(selected_device)

    resolved_commits = collect_resolved_commits(config, model, tokenizer)
    validate_resolved_commits(revision, resolved_commits)
    adapter = locate_pythia_gpt_neox_adapter(model)
    return model, tokenizer, {
        "model_id": model_id,
        "requested_revision": revision,
        "resolved_commit_hashes": sorted(resolved_commits),
        "revision_binding": "VERIFIED_EXACT",
        "model_class": qualified_class_name(model),
        "config_class": qualified_class_name(config),
        "tokenizer_class": qualified_class_name(tokenizer),
        "model_type": str(getattr(config, "model_type", "")),
        "architectures": list(getattr(config, "architectures", []) or []),
        "hidden_size": int(getattr(config, "hidden_size", 0) or 0),
        "num_hidden_layers": int(getattr(config, "num_hidden_layers", 0) or 0),
        "parameter_count": count_parameters(model),
        "device": str(selected_device),
        "requested_torch_dtype": torch_dtype,
        "first_parameter_dtype": first_parameter_dtype(model),
        "local_files_only": bool(local_files_only),
        "trust_remote_code": False,
        "adapter_module_paths": {
            "blocks": list(adapter.block_paths),
            "final_layer_norm": adapter.final_layer_norm_path,
        },
    }


def validate_gpt_neox_config(config: Any) -> None:
    model_type = str(getattr(config, "model_type", ""))
    if model_type != "gpt_neox":
        raise RuntimeError(
            f"Pythia adapter requires config.model_type='gpt_neox', got {model_type!r}"
        )
    architectures = [str(value) for value in (getattr(config, "architectures", None) or [])]
    if architectures and not any("GPTNeoX" in value for value in architectures):
        raise RuntimeError(
            f"Pythia adapter expected a GPTNeoX architecture, got {architectures}"
        )


def resolve_device(torch_module: Any, requested: str) -> Any:
    if requested == "auto":
        requested = "cuda" if torch_module.cuda.is_available() else "cpu"
    if requested == "cuda" and not torch_module.cuda.is_available():
        raise RuntimeError("--device cuda requested but torch.cuda.is_available() is false")
    return torch_module.device(requested)


def resolve_dtype(torch_module: Any, requested: str) -> Any | None:
    if requested == "auto":
        return None
    mapping = {
        "float32": torch_module.float32,
        "float16": torch_module.float16,
        "bfloat16": torch_module.bfloat16,
    }
    return mapping[requested]


def collect_resolved_commits(config: Any, model: Any, tokenizer: Any) -> set[str]:
    candidates = [
        getattr(config, "_commit_hash", None),
        getattr(getattr(model, "config", None), "_commit_hash", None),
        getattr(tokenizer, "_commit_hash", None),
        getattr(tokenizer, "init_kwargs", {}).get("_commit_hash")
        if isinstance(getattr(tokenizer, "init_kwargs", None), dict)
        else None,
    ]
    return {
        str(value).strip().lower()
        for value in candidates
        if value and re.fullmatch(r"[0-9a-fA-F]{40}", str(value).strip())
    }


def validate_resolved_commits(requested_revision: str, resolved_commits: set[str]) -> None:
    requested = validate_exact_revision(requested_revision)
    if not resolved_commits:
        raise RuntimeError(
            "Transformers did not expose a resolved 40-hex commit; exact model binding cannot "
            "be verified"
        )
    if resolved_commits != {requested}:
        raise RuntimeError(
            f"Resolved model/tokenizer commits {sorted(resolved_commits)} do not exactly equal "
            f"the requested revision {requested}"
        )


def locate_pythia_gpt_neox_adapter(model: Any) -> PythiaGPTNeoXAdapter:
    backbone = getattr(model, "gpt_neox", None)
    if backbone is None:
        raise RuntimeError("Pythia adapter requires model.gpt_neox")
    layers = getattr(backbone, "layers", None)
    if layers is None:
        raise RuntimeError("Pythia adapter requires model.gpt_neox.layers")
    blocks = tuple(layers)
    if not blocks:
        raise RuntimeError("Pythia adapter found zero GPT-NeoX blocks")
    final_layer_norm = getattr(backbone, "final_layer_norm", None)
    if final_layer_norm is None:
        raise RuntimeError("Pythia adapter requires model.gpt_neox.final_layer_norm")

    paths_by_id = {id(module): name for name, module in model.named_modules()}
    block_paths = tuple(paths_by_id.get(id(block), "") for block in blocks)
    expected_paths = tuple(f"gpt_neox.layers.{index}" for index in range(len(blocks)))
    if block_paths != expected_paths:
        raise RuntimeError(
            f"Pythia adapter module-path mismatch: expected {expected_paths}, got {block_paths}"
        )
    final_path = paths_by_id.get(id(final_layer_norm), "")
    if final_path != "gpt_neox.final_layer_norm":
        raise RuntimeError(
            "Pythia adapter final-layer-norm path mismatch: expected "
            f"'gpt_neox.final_layer_norm', got {final_path!r}"
        )
    return PythiaGPTNeoXAdapter(
        blocks=blocks,
        final_layer_norm=final_layer_norm,
        block_paths=block_paths,
        final_layer_norm_path=final_path,
    )


def prepare_model_inputs(
    *,
    tokenizer: Any,
    prompt: str,
    model: Any,
    max_tokens: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    encoded = tokenizer(prompt, return_tensors="pt", truncation=False)
    if "input_ids" not in encoded:
        raise RuntimeError("Tokenizer did not return input_ids")
    token_count = int(encoded["input_ids"].shape[-1])
    if token_count < 1:
        raise RuntimeError("Tokenizer returned an empty input")
    if token_count > max_tokens:
        raise RuntimeError(
            f"Prompt token count {token_count} exceeds max_tokens={max_tokens}; refusing silent "
            "truncation"
        )
    token_ids = encoded["input_ids"].detach().cpu().tolist()
    device = first_parameter_device(model)
    model_inputs = {
        key: value.to(device) if hasattr(value, "to") else value
        for key, value in encoded.items()
    }
    return model_inputs, {
        "prompt_utf8_sha256": sha256_bytes(prompt.encode("utf-8")),
        "prompt_character_count": len(prompt),
        "token_count": token_count,
        "token_ids_sha256": sha256_bytes(
            json.dumps(token_ids, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        ),
        "truncation": False,
        "max_tokens": max_tokens,
    }


def capture_and_verify_hook_semantics(
    *,
    model: Any,
    model_inputs: Mapping[str, Any],
    atol: float,
    rtol: float,
) -> dict[str, Any]:
    import torch

    adapter = locate_pythia_gpt_neox_adapter(model)
    block_tensors: dict[int, Any] = {}
    block_metadata: dict[int, dict[str, Any]] = {}
    block_fire_counts = {index: 0 for index in range(len(adapter.blocks))}
    final_norm_pre_inputs: list[Any] = []
    final_norm_outputs: list[Any] = []
    final_norm_input_metadata: list[dict[str, Any]] = []
    final_norm_output_metadata: list[dict[str, Any]] = []
    handles = []

    def make_block_hook(index: int):
        def hook(_module: Any, _inputs: Any, output: Any) -> None:
            block_fire_counts[index] += 1
            tensor = primary_tensor(output, boundary=f"block[{index}] output")
            block_tensors[index] = tensor.detach().cpu()
            block_metadata[index] = tensor_metadata(tensor)

        return hook

    def final_norm_pre_hook(_module: Any, inputs: Any) -> None:
        tensor = primary_tensor(inputs, boundary="final_layer_norm pre-hook input")
        final_norm_pre_inputs.append(tensor.detach().cpu())
        final_norm_input_metadata.append(tensor_metadata(tensor))

    def final_norm_hook(_module: Any, _inputs: Any, output: Any) -> None:
        tensor = primary_tensor(output, boundary="final_layer_norm output")
        final_norm_outputs.append(tensor.detach().cpu())
        final_norm_output_metadata.append(tensor_metadata(tensor))

    try:
        for index, block in enumerate(adapter.blocks):
            handles.append(block.register_forward_hook(make_block_hook(index)))
        handles.append(adapter.final_layer_norm.register_forward_pre_hook(final_norm_pre_hook))
        handles.append(adapter.final_layer_norm.register_forward_hook(final_norm_hook))
        with torch.inference_mode():
            outputs = model(
                **dict(model_inputs),
                output_hidden_states=True,
                use_cache=False,
                return_dict=True,
            )
    finally:
        for handle in handles:
            handle.remove()

    missing_blocks = [
        index for index in range(len(adapter.blocks)) if index not in block_tensors
    ]
    if missing_blocks:
        raise HookEquivalenceError(f"Complete-block hooks did not fire for layers {missing_blocks}")
    wrong_fire_counts = {
        index: count for index, count in block_fire_counts.items() if count != 1
    }
    if wrong_fire_counts:
        raise HookEquivalenceError(
            f"Each complete-block hook must fire exactly once, got {wrong_fire_counts}"
        )
    if len(final_norm_pre_inputs) != 1 or len(final_norm_outputs) != 1:
        raise HookEquivalenceError(
            "final_layer_norm pre/output hooks must each fire exactly once; got "
            f"pre={len(final_norm_pre_inputs)}, output={len(final_norm_outputs)}"
        )

    hidden_states_value = getattr(outputs, "hidden_states", None)
    if hidden_states_value is None:
        raise HookEquivalenceError(
            "Model did not return hidden_states despite output_hidden_states=True"
        )
    hidden_states = tuple(
        primary_tensor(value, boundary=f"hidden_states[{index}]").detach().cpu()
        for index, value in enumerate(hidden_states_value)
    )
    expected_hidden_state_count = len(adapter.blocks) + 1
    if len(hidden_states) != expected_hidden_state_count:
        raise HookEquivalenceError(
            f"Expected {expected_hidden_state_count} hidden states for {len(adapter.blocks)} "
            f"blocks, got {len(hidden_states)}"
        )

    checks = build_equivalence_checks(
        block_tensors=block_tensors,
        hidden_states=hidden_states,
        final_norm_pre_input=final_norm_pre_inputs[0],
        final_norm_output=final_norm_outputs[0],
        atol=atol,
        rtol=rtol,
    )
    modules = [
        {
            "index": index,
            "path": adapter.block_paths[index],
            "class": qualified_class_name(block),
            "hook_fire_count": block_fire_counts[index],
            "output": block_metadata[index],
        }
        for index, block in enumerate(adapter.blocks)
    ]
    checks.update(
        {
            "adapter": "EleutherAI_Pythia_GPT_NeoX_complete_block.v1",
            "block_count": len(adapter.blocks),
            "hidden_state_count": len(hidden_states),
            "hidden_state_shapes": [list(value.shape) for value in hidden_states],
            "block_modules": modules,
            "final_layer_norm": {
                "path": adapter.final_layer_norm_path,
                "class": qualified_class_name(adapter.final_layer_norm),
                "pre_hook_fire_count": len(final_norm_pre_inputs),
                "forward_hook_fire_count": len(final_norm_outputs),
                "input": final_norm_input_metadata[0],
                "output": final_norm_output_metadata[0],
            },
        }
    )
    return checks


def build_equivalence_checks(
    *,
    block_tensors: Mapping[int, Any],
    hidden_states: Sequence[Any],
    final_norm_pre_input: Any,
    final_norm_output: Any,
    atol: float,
    rtol: float,
) -> dict[str, Any]:
    block_count = len(block_tensors)
    expected_indices = set(range(block_count))
    if set(block_tensors) != expected_indices:
        raise HookEquivalenceError(
            f"Block tensor indices must be contiguous 0..{block_count - 1}; got "
            f"{sorted(block_tensors)}"
        )
    if block_count < 1:
        raise HookEquivalenceError("At least one block tensor is required")
    if len(hidden_states) != block_count + 1:
        raise HookEquivalenceError(
            f"Expected block_count + 1 hidden states, got {len(hidden_states)} for "
            f"{block_count} blocks"
        )

    non_final = []
    for index in range(block_count - 1):
        comparison = compare_tensors(
            block_tensors[index], hidden_states[index + 1], atol=atol, rtol=rtol
        )
        non_final.append(
            {
                "block_index": index,
                "block_boundary": f"gpt_neox.layers.{index}.output",
                "hidden_state_index": index + 1,
                "expected_mapping": f"block[{index}] == hidden_states[{index + 1}]",
                "required_gate": True,
                **comparison,
            }
        )

    final_pre_norm = {
        "block_index": block_count - 1,
        "block_boundary": f"gpt_neox.layers.{block_count - 1}.output",
        "comparison_boundary": "gpt_neox.final_layer_norm.pre_hook_input",
        "expected_mapping": "final block output == final_layer_norm pre-hook input",
        "required_gate": True,
        **compare_tensors(
            block_tensors[block_count - 1],
            final_norm_pre_input,
            atol=atol,
            rtol=rtol,
        ),
    }
    post_norm_mapping = {
        "hidden_state_index": len(hidden_states) - 1,
        "comparison_boundary": "gpt_neox.final_layer_norm.output",
        "expected_mapping": "hidden_states[-1] == final_layer_norm output",
        "required_gate": True,
        **compare_tensors(
            hidden_states[-1], final_norm_output, atol=atol, rtol=rtol
        ),
    }
    forbidden_final_mapping = {
        "expected_mapping": (
            "informational only: final block is pre-norm; hidden_states[-1] is post-norm"
        ),
        "required_gate": False,
        "used_as_final_block_equivalence": False,
        **compare_tensors(
            block_tensors[block_count - 1],
            hidden_states[-1],
            atol=atol,
            rtol=rtol,
        ),
    }
    required_pass = (
        all(item["allclose"] for item in non_final)
        and final_pre_norm["allclose"]
        and post_norm_mapping["allclose"]
    )
    return {
        "tolerances": {"atol": float(atol), "rtol": float(rtol)},
        "non_final_block_to_hidden_state": non_final,
        "final_block_to_pre_final_norm": final_pre_norm,
        "post_final_norm_hidden_state_to_norm_output": post_norm_mapping,
        "final_block_to_post_norm_hidden_state_informational": forbidden_final_mapping,
        "all_required_checks_pass": bool(required_pass),
    }


def assert_equivalence_contract(equivalence: Mapping[str, Any]) -> None:
    if bool(equivalence.get("all_required_checks_pass")):
        return
    failed = []
    for item in equivalence.get("non_final_block_to_hidden_state", []):
        if not item.get("allclose"):
            failed.append(item.get("expected_mapping", "non-final block mapping"))
    final_item = equivalence.get("final_block_to_pre_final_norm", {})
    if not final_item.get("allclose"):
        failed.append(final_item.get("expected_mapping", "final pre-norm mapping"))
    norm_item = equivalence.get("post_final_norm_hidden_state_to_norm_output", {})
    if not norm_item.get("allclose"):
        failed.append(norm_item.get("expected_mapping", "post-norm mapping"))
    raise HookEquivalenceError(
        "Required Pythia/GPT-NeoX hook equivalence checks failed: " + "; ".join(failed)
    )


def compare_tensors(left: Any, right: Any, *, atol: float, rtol: float) -> dict[str, Any]:
    import torch

    left_tensor = primary_tensor(left, boundary="comparison left").detach().cpu()
    right_tensor = primary_tensor(right, boundary="comparison right").detach().cpu()
    shape_equal = tuple(left_tensor.shape) == tuple(right_tensor.shape)
    finite_left = bool(torch.isfinite(left_tensor).all().item())
    finite_right = bool(torch.isfinite(right_tensor).all().item())
    exact_equal = bool(shape_equal and torch.equal(left_tensor, right_tensor))
    allclose = bool(
        shape_equal
        and finite_left
        and finite_right
        and torch.allclose(left_tensor, right_tensor, atol=atol, rtol=rtol, equal_nan=False)
    )
    max_abs_diff: float | None = None
    if shape_equal and left_tensor.numel() > 0:
        difference = (left_tensor.to(torch.float64) - right_tensor.to(torch.float64)).abs()
        max_abs_diff = float(difference.max().item())
    return {
        "left_shape": list(left_tensor.shape),
        "right_shape": list(right_tensor.shape),
        "left_dtype": str(left_tensor.dtype),
        "right_dtype": str(right_tensor.dtype),
        "shape_equal": bool(shape_equal),
        "finite_left": finite_left,
        "finite_right": finite_right,
        "exact_equal": exact_equal,
        "allclose": allclose,
        "max_abs_diff": max_abs_diff,
    }


def primary_tensor(value: Any, *, boundary: str) -> Any:
    import torch

    candidate = value[0] if isinstance(value, (tuple, list)) else value
    if not isinstance(candidate, torch.Tensor):
        raise HookEquivalenceError(
            f"{boundary} must expose a tensor as its primary value, got "
            f"{type(candidate).__name__}"
        )
    if candidate.ndim != 3:
        raise HookEquivalenceError(
            f"{boundary} must be [batch, tokens, hidden], got shape {tuple(candidate.shape)}"
        )
    return candidate


def tensor_metadata(value: Any) -> dict[str, Any]:
    return {
        "shape": list(value.shape),
        "dtype": str(value.dtype),
        "device": str(value.device),
        "finite": bool(value.isfinite().all().item()),
    }


def atomic_write_json(path: Path, payload: Mapping[str, Any]) -> dict[str, Any]:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid.uuid4().hex}.tmp")
    try:
        encoded = json.dumps(
            payload,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8") + b"\n"
        with temporary.open("xb") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        persisted = path.read_bytes()
        reopened = json.loads(persisted.decode("utf-8"))
        if reopened != dict(payload):
            raise RuntimeError("Atomically written JSON did not round-trip to the source payload")
        return {
            "path": str(path.resolve()),
            "bytes": len(persisted),
            "sha256": sha256_bytes(persisted),
            "reopen_parse_verified": True,
            "temporary_path_absent": not temporary.exists(),
        }
    finally:
        if temporary.exists():
            temporary.unlink()


def capture_runtime_provenance() -> dict[str, Any]:
    result: dict[str, Any] = {
        "platform": platform.platform(),
        "machine": platform.machine(),
        "python_version": platform.python_version(),
        "python_executable": sys.executable,
        "packages": {
            name: installed_version(name)
            for name in (
                "torch",
                "transformers",
                "huggingface-hub",
                "safetensors",
                "accelerate",
            )
        },
    }
    try:
        import torch

        devices = []
        for index in range(torch.cuda.device_count()):
            properties = torch.cuda.get_device_properties(index)
            devices.append(
                {
                    "index": index,
                    "name": properties.name,
                    "total_memory_bytes": int(properties.total_memory),
                    "capability": list(torch.cuda.get_device_capability(index)),
                }
            )
        result.update(
            {
                "torch_version": str(torch.__version__),
                "cuda_available": bool(torch.cuda.is_available()),
                "torch_cuda_version": str(torch.version.cuda),
                "cuda_device_count": int(torch.cuda.device_count()),
                "cuda_devices": devices,
            }
        )
    except Exception as exc:
        result["torch_probe_error"] = f"{type(exc).__name__}: {exc}"
    try:
        result["nvidia_smi"] = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
            check=True,
            capture_output=True,
            text=True,
            timeout=15,
        ).stdout.splitlines()
    except Exception as exc:
        result["nvidia_smi_error"] = f"{type(exc).__name__}: {exc}"
    return result


def capture_code_provenance() -> dict[str, Any]:
    return {
        "script_path": str(SCRIPT_PATH),
        "script_sha256": sha256_file(SCRIPT_PATH),
        "git_commit": git_text(["rev-parse", "HEAD"]),
        "git_branch": git_text(["branch", "--show-current"]),
        "git_status_for_script": git_text(
            ["status", "--porcelain", "--", str(SCRIPT_PATH)]
        ),
    }


def git_text(arguments: Sequence[str]) -> str | None:
    try:
        return subprocess.run(
            ["git", "-C", str(SCRIPT_PATH.parents[4]), *arguments],
            check=True,
            capture_output=True,
            text=True,
            timeout=15,
        ).stdout.strip() or None
    except Exception:
        return None


def installed_version(package: str) -> str:
    try:
        return importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:
        return "UNAVAILABLE"


def qualified_class_name(value: Any) -> str:
    cls = value.__class__
    return f"{cls.__module__}.{cls.__qualname__}"


def count_parameters(model: Any) -> int:
    return int(sum(int(parameter.numel()) for parameter in model.parameters()))


def first_parameter_device(model: Any) -> Any:
    try:
        return next(model.parameters()).device
    except StopIteration as exc:
        raise RuntimeError("Model exposes no parameters and therefore no execution device") from exc


def first_parameter_dtype(model: Any) -> str:
    try:
        return str(next(model.parameters()).dtype)
    except StopIteration:
        return "UNAVAILABLE"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


if __name__ == "__main__":
    raise SystemExit(main())
